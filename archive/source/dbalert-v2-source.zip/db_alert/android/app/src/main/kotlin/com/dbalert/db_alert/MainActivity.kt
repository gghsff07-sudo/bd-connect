package com.dbalert.db_alert

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
