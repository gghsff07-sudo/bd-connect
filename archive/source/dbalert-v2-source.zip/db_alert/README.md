# DB Alert (Flutter)

WhatsApp-style Firebase database monitor with typed notifications.
See `../download/README.md` for the full user guide.

## Build

```bash
flutter pub get
# android/key.properties (not committed) with:
#   storeFile=<path to dbalert-release.keystore>
#   storePassword=...  keyAlias=dbalert  keyPassword=...
flutter build apk --release --target-platform android-arm,android-arm64
```

The app is configured entirely inside Settings on the phone — no Firebase
config is baked into the APK.

## Layout

- `lib/main.dart` — startup, theme, crash-proof bootstrap
- `lib/types.dart`, `lib/classify.dart`, `lib/normalize.dart` — data model,
  type classification, document auto-detection
- `lib/firebase_rest.dart` — Firestore / Realtime DB REST client (no SDK)
- `lib/storage.dart`, `lib/app_state.dart` — persistence and app state
- `lib/notify.dart` — per-type notification channels
- `lib/poll.dart` — 15-minute check engine (in-app timer + WorkManager)
- `lib/ui/` — WhatsApp-style list, deep-dive detail, settings
