// The check engine: fetch -> merge -> detect new -> notify -> persist.
// Runs from the UI (open/pull-to-refresh/manual), from an in-app 15-minute
// timer, and from Android WorkManager while the app is closed.
import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:workmanager/workmanager.dart';

import 'firebase_rest.dart';
import 'notify.dart';
import 'normalize.dart';
import 'storage.dart';
import 'types.dart';

class Poller {
  static Timer? _inAppTimer;
  static bool _checking = false;

  /// Runs one full check. Returns the number of new items, or null when the
  /// check was skipped (not configured / already running / failed).
  static Future<int?> checkNow() async {
    if (_checking) return null;
    _checking = true;
    try {
      final cfg = await Storage.loadConfig();
      if (!cfg.isConfigured) {
        await Storage.saveLastCheck(CheckResultMeta(
          ok: false,
          at: DateTime.now().millisecondsSinceEpoch,
          error: 'Not configured yet — open Settings and connect your database.',
        ));
        return null;
      }
      try {
        final fresh = await fetchItems(cfg);
        final prev = await Storage.loadItems();
        final merged = mergeItems(prev, fresh);
        final seen = await Storage.loadSeen();
        final firstBaseline = seen.isEmpty;

        // On the very first successful check: mark everything as seen so the
        // user is not spammed with notifications for existing rows.
        final newOnes = firstBaseline ? <Item>[] : diffNew(merged, seen);

        await Storage.saveItems(merged);
        await Storage.saveSeen(merged.map((it) => it.id).toSet());
        final cnt = await Storage.loadCheckCount();
        await Storage.saveCheckCount(cnt + 1);
        await Storage.saveLastCheck(CheckResultMeta(
          ok: true,
          at: DateTime.now().millisecondsSinceEpoch,
          newCount: newOnes.length,
        ));

        if (!firstBaseline && newOnes.isNotEmpty && await Notify.areNotificationsEnabled()) {
          var shown = 0;
          for (final it in newOnes) {
            if (shown >= Notify.maxPerCheck) break;
            await Notify.showItem(it);
            shown++;
          }
          if (newOnes.length > shown) {
            await Notify.showSummary(newOnes.length - shown);
          }
        }
        return newOnes.length;
      } on RestError catch (e) {
        await Storage.saveLastCheck(CheckResultMeta(
          ok: false,
          at: DateTime.now().millisecondsSinceEpoch,
          error: e.message,
        ));
        return null;
      } catch (e) {
        await Storage.saveLastCheck(CheckResultMeta(
          ok: false,
          at: DateTime.now().millisecondsSinceEpoch,
          error: 'Unexpected error: $e',
        ));
        return null;
      }
    } finally {
      _checking = false;
    }
  }

  /// While the app is open, re-check every 15 minutes.
  static void startInAppTimer() {
    _inAppTimer?.cancel();
    _inAppTimer = Timer.periodic(const Duration(minutes: 15), (_) {
      checkNow();
    });
  }

  /// Registers the background check (Android WorkManager, ~every 15 minutes,
  /// survives reboot and app-swipe; Android may delay in Doze).
  static void registerBackground() {
    try {
      Workmanager().initialize(callbackDispatcher);
      Workmanager().registerPeriodicTask(
        'dbalert-periodic-15min',
        'dbCheck',
        frequency: const Duration(minutes: 15),
        existingWorkPolicy: ExistingWorkPolicy.keep,
        constraints: Constraints(networkType: NetworkType.connected),
      );
    } catch (e) {
      debugPrint('Workmanager registration failed: $e');
    }
  }
}

/// Entry point for the WorkManager background isolate.
@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    try {
      await Notify.ensureInit();
      await Poller.checkNow();
    } catch (e) {
      debugPrint('background check failed: $e');
    }
    return true;
  });
}
