// Normalizes documents from Firestore / Realtime DB into [Item] objects.
// Pure logic only — ported from the v1.1.0 Expo app so most schemas work
// without any configuration.
import 'types.dart';

// ---------- field name candidates ----------

const List<String> kTitleKeys = [
  'title', 'heading', 'subject', 'name', 'label', 'summary', 'notificationTitle', 'header', 'topic',
];
const List<String> kBodyKeys = [
  'body', 'message', 'text', 'content', 'description', 'detail', 'msg', 'notificationBody', 'note', 'value',
];
const List<String> kTypeKeys = [
  'type', 'category', 'kind', 'eventType', 'level', 'severity', 'priority', 'tag', 'notificationType',
];
const List<String> kTimeKeys = [
  'createdAt', 'created_at', 'created', 'timestamp', 'time', 'date', 'datetime', 'ts',
  'sentAt', 'sent_at', 'eventTime', 'occurredAt', 'updatedAt', 'updated_at',
];
const List<String> kDoneKeys = [
  'status', 'state', 'done', 'isDone', 'completed', 'completedAt', 'doneAt',
];

// ---------- Firestore typed-value decoding ----------

/// Decodes a Firestore typed value ({stringValue, integerValue, ...}) to plain Dart.
dynamic fsValueToJs(dynamic v) {
  if (v == null) return null;
  if (v is! Map) return null;
  final m = v.cast<String, dynamic>();
  if (m.containsKey('stringValue')) return m['stringValue'];
  if (m.containsKey('integerValue')) {
    final n = num.tryParse('${m['integerValue']}');
    return n;
  }
  if (m.containsKey('doubleValue')) return m['doubleValue'];
  if (m.containsKey('booleanValue')) return m['booleanValue'];
  if (m.containsKey('timestampValue')) return m['timestampValue'];
  if (m.containsKey('mapValue')) {
    final fields = (m['mapValue'] as Map?)?['fields'];
    if (fields is Map) {
      final fm = fields.cast<String, dynamic>();
      return <String, dynamic>{for (final k in fm.keys) k: fsValueToJs(fm[k])};
    }
    return <String, dynamic>{};
  }
  if (m.containsKey('arrayValue')) {
    final vals = (m['arrayValue'] as Map?)?['values'];
    if (vals is List) return [for (final x in vals) fsValueToJs(x)];
    return <dynamic>[];
  }
  if (m.containsKey('referenceValue')) return m['referenceValue'];
  if (m.containsKey('geoPointValue')) return m['geoPointValue'];
  if (m.containsKey('bytesValue')) return m['bytesValue'];
  return null;
}

// ---------- time helpers ----------

/// Converts many common shapes (ms, seconds, ISO string, {seconds}) to epoch ms.
int? toMs(dynamic v) {
  if (v is num) {
    final d = v.toDouble();
    if (d > 1e12) return d.round(); // already ms
    if (d > 1e8) return (d * 1000).round(); // seconds
    return null;
  }
  if (v is String) {
    final digits = num.tryParse(v.trim());
    if (digits != null) return toMs(digits); // numeric string
    final dt = DateTime.tryParse(v);
    return dt?.millisecondsSinceEpoch;
  }
  if (v is Map) {
    final m = v.cast<String, dynamic>();
    final sec = m['_seconds'] ?? m['seconds'];
    if (sec is num) return (sec * 1000).round();
  }
  return null;
}

const String _pushChars = '-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz';

/// Decodes the creation time (ms) encoded in the first 8 chars of a Firebase push id.
int? pushIdToMs(String id) {
  if (id.length < 8) return null;
  int ts = 0;
  for (int i = 0; i < 8; i++) {
    final idx = _pushChars.indexOf(id[i]);
    if (idx < 0) return null;
    ts = ts * 64 + idx;
  }
  return ts;
}

int? _extractTime(Map<String, dynamic> fields, String? metaIso) {
  for (final k in kTimeKeys) {
    final t = toMs(fields[k]);
    if (t != null) return t;
  }
  // second pass: any key mentioning time/date
  final timeRe = RegExp('time|date', caseSensitive: false);
  for (final k in fields.keys) {
    if (timeRe.hasMatch(k)) {
      final t = toMs(fields[k]);
      if (t != null) return t;
    }
  }
  if (metaIso != null) {
    final t = toMs(metaIso);
    if (t != null) return t;
  }
  return null;
}

// ---------- string helpers ----------

String? _asText(dynamic v) {
  if (v is String && v.trim().isNotEmpty) return v.trim();
  if (v is num) return '$v';
  if (v is bool) return '$v';
  return null;
}

String? _pickField(Map<String, dynamic> fields, List<String> keys) {
  for (final k in keys) {
    final v = _asText(fields[k]);
    if (v != null) return v;
  }
  return null;
}

// ---------- done detection ----------

class RemoteDoneInfo {
  final bool done;
  final String? statusField;
  const RemoteDoneInfo(this.done, this.statusField);
}

const List<String> _doneWords = ['done', 'completed', 'complete', 'closed', 'resolved', 'read', 'true', 'yes', '1'];
const List<String> _activeWords = ['pending', 'active', 'new', 'open', 'todo', 'false', 'no', '0'];

RemoteDoneInfo detectRemoteDone(Map<String, dynamic> fields) {
  for (final k in kDoneKeys) {
    if (!fields.containsKey(k)) continue;
    final v = fields[k];
    if (v is bool) return RemoteDoneInfo(v, k);
    if (v is String) {
      final s = v.trim().toLowerCase();
      if (_doneWords.contains(s)) return RemoteDoneInfo(true, k);
      if (_activeWords.contains(s)) return RemoteDoneInfo(false, k);
    }
  }
  return const RemoteDoneInfo(false, null);
}

// ---------- normalization ----------

class RawDoc {
  final String id;
  final Map<String, dynamic> fields;
  final String? metaTimeIso;
  final DbKind kind;
  const RawDoc({required this.id, required this.fields, this.metaTimeIso, required this.kind});
}

Item normalizeDoc(RawDoc doc) {
  final fields = doc.fields;
  final title = _pickField(fields, kTitleKeys) ?? 'New update';
  final body = _pickField(fields, kBodyKeys) ?? '';
  final type = _pickField(fields, kTypeKeys) ?? 'general';
  final timeMs = _extractTime(fields, doc.metaTimeIso);
  final doneInfo = detectRemoteDone(fields);

  int sortMs = timeMs ?? 0;
  if (sortMs == 0) {
    final pid = pushIdToMs(doc.id);
    if (pid != null) sortMs = pid;
  }

  return Item(
    id: doc.id,
    title: title,
    body: body,
    type: type,
    timeMs: timeMs,
    sortMs: sortMs,
    raw: fields,
    remoteDone: doneInfo.done,
    statusField: doneInfo.statusField,
    kind: doc.kind,
  );
}

// ---------- merge / diff (used by the poller) ----------

/// Merges freshly fetched items over cached ones, keeps newest first, caps length.
List<Item> mergeItems(List<Item> prev, List<Item> fresh, {int cap = 300}) {
  final byId = <String, Item>{};
  for (final it in prev) {
    byId[it.id] = it;
  }
  for (final it in fresh) {
    byId[it.id] = it;
  }
  final merged = byId.values.toList()
    ..sort((a, b) => b.sortMs.compareTo(a.sortMs));
  if (merged.length > cap) merged.removeRange(cap, merged.length);
  return merged;
}

/// Returns items that have never been seen before (ordered oldest first).
List<Item> diffNew(List<Item> items, Set<String> seenIds) {
  final out = items.where((it) => !seenIds.contains(it.id)).toList()
    ..sort((a, b) => a.sortMs.compareTo(b.sortMs));
  return out;
}

// ---------- display helpers ----------

const List<String> _months = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

int _startOfDay(int ms) {
  final d = DateTime.fromMillisecondsSinceEpoch(ms);
  return DateTime(d.year, d.month, d.day).millisecondsSinceEpoch;
}

String dayKey(int ms) {
  final d = DateTime.fromMillisecondsSinceEpoch(ms);
  return '${d.year}-${d.month}-${d.day}';
}

String dayLabel(int ms) {
  final today = _startOfDay(DateTime.now().millisecondsSinceEpoch);
  final day = _startOfDay(ms);
  if (day == today) return 'Today';
  if (day == today - 86400000) return 'Yesterday';
  final d = DateTime.fromMillisecondsSinceEpoch(ms);
  return '${_two(d.day)} ${_months[d.month - 1]} ${d.year}';
}

String _two(int n) => n.toString().padLeft(2, '0');

String timeLabel(int ms) {
  final d = DateTime.fromMillisecondsSinceEpoch(ms);
  final h = d.hour;
  final m = d.minute;
  final ampm = h >= 12 ? 'PM' : 'AM';
  final h12 = h % 12 == 0 ? 12 : h % 12;
  return '$h12:${_two(m)} $ampm';
}

String fullTimeLabel(int ms) {
  if (ms == 0) return 'Unknown time';
  return '${dayLabel(ms)}, ${timeLabel(ms)}';
}
