// Single app-wide observable state.
import 'dart:async';

import 'package:flutter/foundation.dart';

import 'firebase_rest.dart';
import 'notify.dart';
import 'poll.dart';
import 'storage.dart';
import 'types.dart';

class AppState extends ChangeNotifier {
  List<Item> items = [];
  AppConfig config = AppConfig();
  Map<String, bool> localDone = {};
  Set<String> readIds = {};
  CheckResultMeta? lastCheck;
  int checkCount = 0;
  bool syncing = false;
  bool notifPermission = true;

  /// Set when a notification was tapped (payload = item id); the home screen
  /// consumes it and opens the detail view.
  String? pendingOpenId;

  Future<void> load() async {
    try {
      items = await Storage.loadItems();
      config = await Storage.loadConfig();
      localDone = await Storage.loadLocalDone();
      readIds = await Storage.loadRead();
      lastCheck = await Storage.loadLastCheck();
      checkCount = await Storage.loadCheckCount();
    } catch (e) {
      debugPrint('AppState.load failed: $e');
    }
    notifyListeners();
  }

  /// Re-reads persisted state without hitting the network (used on app resume).
  Future<void> reloadFromStorage() async {
    await load();
  }

  bool effectiveDone(Item it) => localDone[it.id] ?? it.remoteDone;

  bool isUnread(Item it) => !readIds.contains(it.id) && !effectiveDone(it);

  List<Item> get activeItems =>
      items.where((it) => !effectiveDone(it)).toList();

  List<Item> get doneItems =>
      items.where((it) => effectiveDone(it)).toList();

  int get unreadCount => items.where((it) => isUnread(it)).length;

  Item? byId(String id) {
    for (final it in items) {
      if (it.id == id) return it;
    }
    return null;
  }

  /// Runs a check now (pull-to-refresh, refresh button, app open).
  Future<void> refresh({bool manual = false}) async {
    if (syncing) return;
    syncing = true;
    notifyListeners();
    try {
      await Poller.checkNow();
    } finally {
      await reloadFromStorage();
      syncing = false;
      notifyListeners();
    }
  }

  Future<void> saveConfig(AppConfig cfg) async {
    config = cfg;
    await Storage.saveConfig(cfg);
    clearAuthCache();
    notifyListeners();
  }

  Future<void> markRead(Item item) async {
    if (readIds.contains(item.id)) return;
    readIds.add(item.id);
    await Storage.saveRead(readIds);
    notifyListeners();
  }

  Future<void> markAllRead() async {
    readIds = items.map((it) => it.id).toSet();
    await Storage.saveRead(readIds);
    notifyListeners();
  }

  /// Marks done locally (instant) and tries to write back to the database.
  /// Returns a human-readable result message for a snackbar.
  Future<String> markDone(Item item, bool done) async {
    localDone[item.id] = done;
    await Storage.saveLocalDone(localDone);
    notifyListeners();
    if (done) {
      await Notify.cancelFor(item);
    }
    String remoteMsg;
    if (!config.isConfigured) {
      remoteMsg = done ? 'Marked done on this phone.' : 'Marked as active on this phone.';
    } else {
      try {
        await markDoneRemote(config, item, done);
        remoteMsg = done
            ? 'Marked done — database updated.'
            : 'Marked as active — database updated.';
      } catch (e) {
        final msg = e is RestError ? e.message : '$e';
        remoteMsg = done
            ? 'Marked done on this phone. Database was not updated: $msg'
            : 'Marked as active on this phone. Database was not updated: $msg';
      }
    }
    await reloadFromStorage();
    return remoteMsg;
  }

  /// "Re-baseline": treat everything currently in the database as seen.
  Future<void> rebase() async {
    await Storage.clearSeen();
    await Poller.checkNow();
    await reloadFromStorage();
  }

  void consumePendingOpen() {
    pendingOpenId = null;
    notifyListeners();
  }

  /// Public way for main() to request opening an item (notification tap).
  void requestOpen(String itemId) {
    pendingOpenId = itemId;
    notifyListeners();
  }
}
