// Local persistence on top of SharedPreferences.
// All reads/writes are defensive: any failure returns a default instead of
// throwing (crash-proof parity with v1.1.0).
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'types.dart';

class Storage {
  static const String kItems = 'dbalert.items';
  static const String kConfig = 'dbalert.config';
  static const String kSeen = 'dbalert.seen';
  static const String kRead = 'dbalert.read';
  static const String kLocalDone = 'dbalert.localDone';
  static const String kLastCheck = 'dbalert.lastCheck';
  static const String kCheckCount = 'dbalert.checkCount';

  static Future<SharedPreferences> _prefs() => SharedPreferences.getInstance();

  // ----- items -----

  static Future<List<Item>> loadItems() async {
    try {
      final p = await _prefs();
      final s = p.getString(kItems);
      if (s == null || s.isEmpty) return [];
      final decoded = jsonDecode(s);
      if (decoded is! List) return [];
      return [
        for (final e in decoded)
          if (e is Map) Item.fromMap(e.cast<String, dynamic>())
      ];
    } catch (_) {
      return [];
    }
  }

  static Future<void> saveItems(List<Item> items) async {
    try {
      final p = await _prefs();
      await p.setString(kItems, jsonEncode([for (final it in items) it.toMap()]));
    } catch (_) {}
  }

  // ----- config -----

  static Future<AppConfig> loadConfig() async {
    try {
      final p = await _prefs();
      final s = p.getString(kConfig);
      if (s == null || s.isEmpty) return AppConfig();
      final decoded = jsonDecode(s);
      if (decoded is Map<String, dynamic>) return AppConfig.fromMap(decoded);
      return AppConfig();
    } catch (_) {
      return AppConfig();
    }
  }

  static Future<void> saveConfig(AppConfig cfg) async {
    try {
      final p = await _prefs();
      await p.setString(kConfig, jsonEncode(cfg.toMap()));
    } catch (_) {}
  }

  // ----- id sets -----

  static Future<Set<String>> loadSeen() async {
    try {
      final p = await _prefs();
      return (p.getStringList(kSeen) ?? const <String>[]).toSet();
    } catch (_) {
      return {};
    }
  }

  static Future<void> saveSeen(Set<String> ids) async {
    try {
      final p = await _prefs();
      await p.setStringList(kSeen, ids.toList());
    } catch (_) {}
  }

  static Future<void> clearSeen() async {
    try {
      final p = await _prefs();
      await p.remove(kSeen);
    } catch (_) {}
  }

  static Future<Set<String>> loadRead() async {
    try {
      final p = await _prefs();
      return (p.getStringList(kRead) ?? const <String>[]).toSet();
    } catch (_) {
      return {};
    }
  }

  static Future<void> saveRead(Set<String> ids) async {
    try {
      final p = await _prefs();
      await p.setStringList(kRead, ids.toList());
    } catch (_) {}
  }

  // ----- local done flags -----

  static Future<Map<String, bool>> loadLocalDone() async {
    try {
      final p = await _prefs();
      final s = p.getString(kLocalDone);
      if (s == null || s.isEmpty) return {};
      final decoded = jsonDecode(s);
      if (decoded is Map) {
        return decoded.map((k, v) => MapEntry('$k', v == true));
      }
      return {};
    } catch (_) {
      return {};
    }
  }

  static Future<void> saveLocalDone(Map<String, bool> done) async {
    try {
      final p = await _prefs();
      await p.setString(kLocalDone, jsonEncode(done));
    } catch (_) {}
  }

  // ----- diagnostics -----

  static Future<CheckResultMeta?> loadLastCheck() async {
    try {
      final p = await _prefs();
      final s = p.getString(kLastCheck);
      if (s == null || s.isEmpty) return null;
      final decoded = jsonDecode(s);
      if (decoded is Map<String, dynamic>) return CheckResultMeta.fromMap(decoded);
      return null;
    } catch (_) {
      return null;
    }
  }

  static Future<void> saveLastCheck(CheckResultMeta meta) async {
    try {
      final p = await _prefs();
      await p.setString(kLastCheck, jsonEncode(meta.toMap()));
    } catch (_) {}
  }

  static Future<int> loadCheckCount() async {
    try {
      final p = await _prefs();
      return p.getInt(kCheckCount) ?? 0;
    } catch (_) {
      return 0;
    }
  }

  static Future<void> saveCheckCount(int n) async {
    try {
      final p = await _prefs();
      await p.setInt(kCheckCount, n);
    } catch (_) {}
  }
}
