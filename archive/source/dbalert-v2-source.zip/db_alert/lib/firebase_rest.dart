// Firebase REST clients for Firestore and Realtime Database.
// Pure HTTP (no native Firebase SDK) — this is what keeps the app
// crash-proof: there is no config-time native initialization that can throw.
// Ported from v1.1.0.
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'normalize.dart';
import 'types.dart';

class RestError implements Exception {
  final String message;
  final int status;
  RestError(this.message, [this.status = 0]);
  @override
  String toString() => message;
}

class TestResult {
  final bool ok;
  final String message;
  final int? itemCount;
  const TestResult(this.ok, this.message, {this.itemCount});
}

// ---------- auth ----------

String? _authEmail;
String? _authToken;
int _authExpiresAt = 0;

void clearAuthCache() {
  _authEmail = null;
  _authToken = null;
  _authExpiresAt = 0;
}

/// Signs in with email/password (optional) and returns an idToken, or null.
Future<String?> getAuthToken(AppConfig cfg, {bool force = false}) async {
  final email = cfg.authEmail.trim();
  final password = cfg.authPassword;
  if (email.isEmpty || password.isEmpty) return null;
  final nowMs = DateTime.now().millisecondsSinceEpoch;
  if (!force && _authToken != null && _authEmail == email && _authExpiresAt > nowMs + 60000) {
    return _authToken;
  }
  final key = cfg.apiKey.trim();
  if (key.isEmpty) {
    throw RestError('Sign-in email/password are set but the Web API key is missing.', 400);
  }
  final url = Uri.parse(
      'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${Uri.encodeComponent(key)}');
  http.Response res;
  try {
    res = await http.post(url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email, 'password': password, 'returnSecureToken': true}));
  } catch (e) {
    throw RestError('Network error: $e. Check your internet connection.', 0);
  }
  Map<String, dynamic>? json;
  try {
    final decoded = jsonDecode(res.body);
    if (decoded is Map<String, dynamic>) json = decoded;
  } catch (_) {}
  final idToken = json?['idToken'];
  if (res.statusCode != 200 || idToken is! String || idToken.isEmpty) {
    final msg = (json?['error'] as Map?)?['message'] ?? 'HTTP ${res.statusCode}';
    throw RestError('Sign-in failed: $msg', res.statusCode);
  }
  final expiresInSec = int.tryParse('${json?['expiresIn'] ?? '3600'}') ?? 3600;
  _authEmail = email;
  _authToken = idToken;
  _authExpiresAt = nowMs + expiresInSec * 1000;
  return idToken;
}

// ---------- fetch helper ----------

Future<Map<String, dynamic>?> _fetchJson(Uri url,
    {String? method, Map<String, String>? headers, Object? body}) async {
  http.Response res;
  try {
    final req = http.Request(method ?? 'GET', url);
    if (headers != null) req.headers.addAll(headers);
    if (body != null) req.body = body is String ? body : jsonEncode(body);
    final streamed = await req.send();
    res = await http.Response.fromStream(streamed);
  } catch (e) {
    throw RestError('Network error: $e. Check your internet connection.', 0);
  }
  Map<String, dynamic>? decoded;
  try {
    final d = jsonDecode(res.body);
    if (d is Map<String, dynamic>) decoded = d;
  } catch (_) {}
  if (res.statusCode != 200) {
    throw RestError(_apiErrorMessage(decoded, res.statusCode, 'Request failed'), res.statusCode);
  }
  return decoded;
}

String _apiErrorMessage(Map<String, dynamic>? body, int status, String fallback) {
  final err = body?['error'];
  String? raw;
  if (err is Map) raw = err['message'] as String?;
  if (raw != null && raw.isNotEmpty) {
    if (RegExp('permission', caseSensitive: false).hasMatch(raw) || status == 403) {
      return '$fallback: permission denied. Check your database rules, API key or sign-in details.';
    }
    if (status == 404) {
      return '$fallback: not found. Check the project id and the collection/path name.';
    }
    if (status == 401) {
      return '$fallback: unauthorized. Check your Web API key or sign-in details.';
    }
    return '$fallback: $raw';
  }
  if (status == 404) return '$fallback: not found. Check the project id and the collection/path name.';
  if (status == 401 || status == 403) {
    return '$fallback: permission denied. Check your database rules, API key or sign-in details.';
  }
  return '$fallback: HTTP $status';
}

// ---------- Firestore ----------

Map<String, String> _firestoreHeaders(String? token, String apiKey) {
  final h = <String, String>{};
  final key = apiKey.trim();
  if (key.isNotEmpty) h['x-goog-api-key'] = key;
  if (token != null && token.isNotEmpty) h['Authorization'] = 'Bearer $token';
  return h;
}

String _encodeDocPath(String path) => path
    .split('/')
    .where((s) => s.isNotEmpty)
    .map((s) => Uri.encodeComponent(s))
    .join('/');

Future<List<Map<String, dynamic>>> _firestoreListOnce(
    AppConfig cfg, String? token) async {
  final pid = cfg.projectId.trim();
  final path = _encodeDocPath(cfg.path.trim().isEmpty ? 'notifications' : cfg.path.trim());
  final url = Uri.parse(
      'https://firestore.googleapis.com/v1/projects/${Uri.encodeComponent(pid)}/databases/(default)/documents/$path?pageSize=250');
  final body = await _fetchJson(url, headers: _firestoreHeaders(token, cfg.apiKey));
  final docs = body?['documents'];
  if (docs is List) {
    return [for (final d in docs) if (d is Map<String, dynamic>) d];
  }
  return [];
}

/// Reads the collection and returns normalized items. Retries once with a
/// fresh token on 401.
Future<List<Item>> fetchFirestoreItems(AppConfig cfg) async {
  var token = await getAuthToken(cfg);
  List<Map<String, dynamic>> docs;
  try {
    docs = await _firestoreListOnce(cfg, token);
  } on RestError catch (e) {
    if (e.status == 401 && token != null) {
      token = await getAuthToken(cfg, force: true);
      docs = await _firestoreListOnce(cfg, token);
    } else {
      rethrow;
    }
  }
  final out = <Item>[];
  for (final d in docs) {
    final name = d['name'];
    if (name is! String || name.isEmpty) continue;
    final id = name.split('/').last;
    final typed = d['fields'];
    final raw = <String, dynamic>{};
    if (typed is Map) {
      final tm = typed.cast<String, dynamic>();
      for (final k in tm.keys) {
        raw[k] = fsValueToJs(tm[k]);
      }
    }
    out.add(normalizeDoc(RawDoc(
      id: id,
      fields: raw,
      metaTimeIso: (d['updateTime'] ?? d['createTime']) as String?,
      kind: DbKind.firestore,
    )));
  }
  return out;
}

// ---------- Realtime Database ----------

String rtdbBaseUrl(AppConfig cfg) {
  final url = cfg.dbUrl.trim();
  if (url.isNotEmpty) {
    return url.replaceAll(RegExp('/+\$'), '');
  }
  final pid = cfg.projectId.trim();
  return 'https://$pid-default-rtdb.firebaseio.com';
}

String _encodeRtdbPath(String path) => path
    .split('/')
    .where((s) => s.isNotEmpty)
    .map((s) => Uri.encodeComponent(s))
    .join('/');

Future<Map<String, dynamic>?> _rtdbListOnce(AppConfig cfg, String? token) async {
  final base = rtdbBaseUrl(cfg);
  final path = _encodeRtdbPath(cfg.path.trim().isEmpty ? 'notifications' : cfg.path.trim());
  final authParam = token != null && token.isNotEmpty ? '?auth=${Uri.encodeComponent(token)}' : '';
  final body = await _fetchJson(Uri.parse('$base/$path.json$authParam'));
  return body;
}

Future<List<Item>> fetchRtdbItems(AppConfig cfg) async {
  var token = await getAuthToken(cfg);
  Map<String, dynamic>? data;
  try {
    data = await _rtdbListOnce(cfg, token);
  } on RestError catch (e) {
    if (e.status == 401 && token != null) {
      token = await getAuthToken(cfg, force: true);
      data = await _rtdbListOnce(cfg, token);
    } else {
      rethrow;
    }
  }
  final out = <Item>[];
  if (data != null) {
    for (final key in data.keys) {
      final val = data[key];
      Map<String, dynamic> fields;
      if (val is Map<String, dynamic>) {
        fields = val;
      } else if (val is Map) {
        fields = val.cast<String, dynamic>();
      } else {
        fields = {'value': val};
      }
      out.add(normalizeDoc(RawDoc(id: key, fields: fields, kind: DbKind.rtdb)));
    }
  }
  return out;
}

// ---------- public API ----------

Future<List<Item>> fetchItems(AppConfig cfg) {
  return cfg.kind == DbKind.rtdb ? fetchRtdbItems(cfg) : fetchFirestoreItems(cfg);
}

/// Cheap connectivity probe used by "Test connection" in settings.
Future<TestResult> testConnection(AppConfig cfg) async {
  try {
    final token = await getAuthToken(cfg);
    if (cfg.kind == DbKind.rtdb) {
      final data = await _rtdbListOnce(cfg, token);
      final n = data?.length ?? 0;
      return TestResult(true, 'Connected. Found $n ${n == 1 ? 'entry' : 'entries'} in the database.',
          itemCount: n);
    }
    final docs = await _firestoreListOnce(cfg, token);
    return TestResult(
        true, 'Connected. Found ${docs.length} ${docs.length == 1 ? 'document' : 'documents'} in the collection.',
        itemCount: docs.length);
  } catch (e) {
    return TestResult(false, e is RestError ? e.message : e.toString());
  }
}

// ---------- mark as done (write-back) ----------

/// Attempts to mark a document done in the database. Throws a readable
/// message on failure (caller keeps the local "done" anyway).
Future<void> markDoneRemote(AppConfig cfg, Item item, bool done) async {
  final token = await getAuthToken(cfg);
  final nowIso = DateTime.now().toUtc().toIso8601String();
  final field = item.statusField ?? 'status';
  final isBoolField = RegExp('done|completed|isdone', caseSensitive: false).hasMatch(field);

  if (cfg.kind == DbKind.rtdb) {
    final base = rtdbBaseUrl(cfg);
    final path = _encodeRtdbPath(cfg.path.trim());
    final authParam = token != null && token.isNotEmpty ? '?auth=${Uri.encodeComponent(token)}' : '';
    final payload = <String, dynamic>{
      'doneAt': nowIso,
      field: isBoolField ? done : (done ? 'done' : 'active'),
    };
    await _fetchJson(
        Uri.parse('$base/$path/${Uri.encodeComponent(item.id)}.json$authParam'),
        method: 'PATCH',
        headers: {'Content-Type': 'application/json'},
        body: payload);
    return;
  }

  final pid = cfg.projectId.trim();
  final path = _encodeDocPath(cfg.path.trim());
  final fields = <String, dynamic>{
    'doneAt': {'timestampValue': nowIso},
    field: isBoolField
        ? {'booleanValue': done}
        : {'stringValue': done ? 'done' : 'active'},
  };
  final mask =
      'updateMask.fieldPaths=${Uri.encodeQueryComponent(field)}&updateMask.fieldPaths=doneAt';
  final url = Uri.parse(
      'https://firestore.googleapis.com/v1/projects/${Uri.encodeComponent(pid)}/databases/(default)/documents/$path/${Uri.encodeComponent(item.id)}?$mask');
  await _fetchJson(url,
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        ..._firestoreHeaders(token, cfg.apiKey),
      },
      body: {'fields': fields});
}
