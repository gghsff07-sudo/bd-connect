// Small shared widgets.
import 'package:flutter/material.dart';

import '../theme.dart';

// WhatsApp-ish chat bubble.
class Bubble extends StatelessWidget {
  final Color color;
  final Widget child;
  final bool tailRight;
  final EdgeInsets padding;
  final double maxWidthFactor;

  const Bubble({
    super.key,
    required this.color,
    required this.child,
    this.tailRight = false,
    this.padding = const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
    this.maxWidthFactor = 0.82,
  });

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: tailRight ? Alignment.centerRight : Alignment.centerLeft,
      child: FractionallySizedBox(
        widthFactor: maxWidthFactor,
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(12),
              topRight: const Radius.circular(12),
              bottomLeft: Radius.circular(tailRight ? 12 : 2),
              bottomRight: Radius.circular(tailRight ? 2 : 12),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.06),
                blurRadius: 2,
                offset: const Offset(0, 1),
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}

/// "Not configured" banner shown above the list.
class NotConfiguredBanner extends StatelessWidget {
  final VoidCallback onOpenSettings;
  const NotConfiguredBanner({super.key, required this.onOpenSettings});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFFFFF8E1),
      child: InkWell(
        onTap: onOpenSettings,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Row(
            children: [
              const Icon(Icons.cloud_off_outlined, size: 20, color: Color(0xFFB26A00)),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'Not configured yet — tap to connect your database.',
                  style: TextStyle(color: Color(0xFF6D4C00), fontSize: 13),
                ),
              ),
              const Icon(Icons.chevron_right, size: 20, color: Color(0xFFB26A00)),
            ],
          ),
        ),
      ),
    );
  }
}

/// Friendly empty state.
class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  const EmptyState({super.key, required this.icon, required this.title, required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 64, color: T.textSecondary.withValues(alpha: 0.5)),
            const SizedBox(height: 16),
            Text(title,
                style: const TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w600, color: T.textPrimary)),
            const SizedBox(height: 6),
            Text(message,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 13.5, color: T.textSecondary)),
          ],
        ),
      ),
    );
  }
}

/// Blue WhatsApp "read" double ticks.
class BlueTicks extends StatelessWidget {
  final double size;
  const BlueTicks({super.key, this.size = 16});

  @override
  Widget build(BuildContext context) {
    return Icon(Icons.done_all, size: size, color: T.ticksBlue);
  }
}
