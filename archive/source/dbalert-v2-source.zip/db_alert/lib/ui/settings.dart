// Settings: connect your Firebase database (Firestore or Realtime DB) over
// REST — everything is typed here in the app, nothing is baked into the APK.
import 'package:flutter/material.dart';


import '../firebase_rest.dart';
import '../main.dart';
import '../notify.dart';
import '../theme.dart';
import '../types.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _projectId;
  late final TextEditingController _apiKey;
  late final TextEditingController _path;
  late final TextEditingController _dbUrl;
  late final TextEditingController _email;
  late final TextEditingController _password;
  late DbKind _kind;
  bool _obscure = true;
  bool _testing = false;
  String? _testResult;
  bool _testOk = false;

  @override
  void initState() {
    super.initState();
    final c = appState.config;
    _projectId = TextEditingController(text: c.projectId);
    _apiKey = TextEditingController(text: c.apiKey);
    _path = TextEditingController(text: c.path);
    _dbUrl = TextEditingController(text: c.dbUrl);
    _email = TextEditingController(text: c.authEmail);
    _password = TextEditingController(text: c.authPassword);
    _kind = c.kind;
  }

  @override
  void dispose() {
    _projectId.dispose();
    _apiKey.dispose();
    _path.dispose();
    _dbUrl.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  AppConfig _configFromForm() => AppConfig(
        kind: _kind,
        projectId: _projectId.text.trim(),
        apiKey: _apiKey.text.trim(),
        path: _path.text.trim().isEmpty ? 'notifications' : _path.text.trim(),
        dbUrl: _dbUrl.text.trim(),
        authEmail: _email.text.trim(),
        authPassword: _password.text,
      );

  Future<void> _testConnection() async {
    setState(() {
      _testing = true;
      _testResult = null;
    });
    final res = await testConnection(_configFromForm());
    if (!mounted) return;
    setState(() {
      _testing = false;
      _testResult = res.message;
      _testOk = res.ok;
    });
  }

  Future<void> _save() async {
    final cfg = _configFromForm();
    await appState.saveConfig(cfg);
    if (!mounted) return;
    // Run a check right away (also builds the "seen" baseline on first save).
    unawaitedCheck();
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Saved. DB Alert now watches this database.')));
  }

  void unawaitedCheck() {
    appState.refresh();
  }

  Future<void> _rebase() async {
    await appState.rebase();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content:
              Text('Everything currently in the database is now treated as seen.')));
    }
  }

  Future<void> _testNotification() async {
    final ok = await Notify.requestPermission();
    if (!mounted) return;
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Notification permission is off for DB Alert.')));
      return;
    }
    await Notify.showTest();
  }

  @override
  Widget build(BuildContext context) {
    final last = appState.lastCheck;
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _sectionTitle('Database'),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12), side: const BorderSide(color: T.cardBorder)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SegmentedButton<DbKind>(
                    segments: const [
                      ButtonSegment(value: DbKind.firestore, label: Text('Firestore')),
                      ButtonSegment(value: DbKind.rtdb, label: Text('Realtime DB')),
                    ],
                    selected: {_kind},
                    onSelectionChanged: (s) => setState(() => _kind = s.first),
                  ),
                  const SizedBox(height: 14),
                  _field(_projectId, 'Project ID', 'e.g. my-shop-3f2k1',
                      icon: Icons.folder_outlined),
                  if (_kind == DbKind.firestore) ...[
                    _field(_apiKey, 'Web API key', 'starts with AIza… (Project settings → General)',
                        icon: Icons.vpn_key_outlined),
                    _field(_path, 'Collection', 'e.g. notifications', icon: Icons.list_alt_outlined),
                  ] else ...[
                    _field(_path, 'Path', 'e.g. notifications', icon: Icons.list_alt_outlined),
                    _field(_dbUrl, 'Database URL (optional)',
                        'https://my-project-default-rtdb.firebaseio.com',
                        icon: Icons.link),
                    _field(_apiKey, 'Web API key (optional)', 'needed for sign-in',
                        icon: Icons.vpn_key_outlined),
                  ],
                  const SizedBox(height: 10),
                  Text(
                    'Where to find these: Firebase console → your project → ⚙ Project settings → General.',
                    style: const TextStyle(fontSize: 12, color: T.textSecondary),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          _sectionTitle('Sign-in (only if your rules require it)'),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12), side: const BorderSide(color: T.cardBorder)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  _field(_email, 'Email', 'user@example.com', icon: Icons.mail_outline),
                  _field(_password, 'Password', '', icon: Icons.lock_outline, obscure: _obscure,
                      toggle: () => setState(() => _obscure = !_obscure)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _testing ? null : _testConnection,
                  icon: _testing
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.wifi_tethering),
                  label: Text(_testing ? 'Testing…' : 'Test connection'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: T.header),
                  onPressed: _save,
                  icon: const Icon(Icons.check),
                  label: const Text('Save & activate'),
                ),
              ),
            ],
          ),
          if (_testResult != null) ...[
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _testOk ? const Color(0xFFE8F8EE) : const Color(0xFFFDECEA),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  Icon(_testOk ? Icons.check_circle : Icons.error_outline,
                      size: 18, color: _testOk ? T.accentPressed : T.danger),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _testResult!,
                      style: const TextStyle(fontSize: 13, color: T.textPrimary),
                    ),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 24),
          _sectionTitle('Notifications'),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12), side: const BorderSide(color: T.cardBorder)),
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.notifications_active_outlined),
                  title: const Text('Send test notification'),
                  subtitle: const Text('Checks that notifications can reach you.',
                      style: TextStyle(fontSize: 12)),
                  onTap: _testNotification,
                ),
                const Divider(height: 1, indent: 16, endIndent: 16),
                ListTile(
                  leading: const Icon(Icons.visibility_off_outlined),
                  title: const Text('Treat existing items as seen'),
                  subtitle: const Text(
                      'Re-baseline: no notifications for what is already in the database.',
                      style: TextStyle(fontSize: 12)),
                  onTap: _rebase,
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          _sectionTitle('Diagnostics'),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12), side: const BorderSide(color: T.cardBorder)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _diagRow('Last check',
                      last == null ? 'never' : '${_ago(last.at)} · ${last.ok ? 'OK' : 'failed'}'),
                  if (last?.error != null && last!.error!.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(left: 8, top: 4),
                      child: Text(
                        last.error!,
                        style: const TextStyle(fontSize: 12, color: T.danger),
                      ),
                    ),
                  _diagRow('New items at last check', '${last?.newCount ?? 0}'),
                  _diagRow('Total checks run', '${appState.checkCount}'),
                  _diagRow('Items in history', '${appState.items.length}'),
                  _diagRow(
                      'Background checks', 'every 15 minutes (WorkManager, battery-optimized)'),
                  const SizedBox(height: 6),
                  const Text(
                    'Tip: for best reliability set Android Settings → Apps → DB Alert → Battery → Unrestricted.',
                    style: TextStyle(fontSize: 12, color: T.textSecondary),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          Center(
            child: Text(
              'DB Alert v2.0.0 (Flutter) · rebuild of v1.1.0',
              style: const TextStyle(fontSize: 12, color: T.textSecondary),
            ),
          ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }

  String _ago(int ms) {
    final diff = DateTime.now().millisecondsSinceEpoch - ms;
    if (diff < 60000) return 'just now';
    if (diff < 3600000) return '${diff ~/ 60000} min ago';
    if (diff < 86400000) return '${diff ~/ 3600000} h ago';
    return '${diff ~/ 86400000} d ago';
  }

  Widget _sectionTitle(String s) => Padding(
        padding: const EdgeInsets.only(left: 8, bottom: 6),
        child: Text(s.toUpperCase(),
            style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: T.header,
                letterSpacing: 0.6)),
      );

  Widget _diagRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
              child: Text(label,
                  style: const TextStyle(fontSize: 13, color: T.textSecondary))),
          Expanded(
              flex: 2,
              child: Text(value,
                  textAlign: TextAlign.right,
                  style: const TextStyle(
                      fontSize: 13, color: T.textPrimary, fontWeight: FontWeight.w500))),
        ],
      ),
    );
  }

  Widget _field(TextEditingController ctl, String label, String hint,
      {IconData? icon, bool obscure = false, VoidCallback? toggle}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: ctl,
        obscureText: obscure,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          isDense: true,
          prefixIcon: icon != null ? Icon(icon, size: 20) : null,
          suffixIcon: toggle != null
              ? IconButton(
                  icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                      size: 20),
                  onPressed: toggle)
              : null,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
        ),
      ),
    );
  }
}
