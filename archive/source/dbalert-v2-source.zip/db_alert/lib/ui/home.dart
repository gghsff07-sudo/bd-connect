// WhatsApp-style home: green header, tabs (Updates / Done), day-grouped
// history list with unread badges, search, pull-to-refresh.
import 'package:flutter/material.dart';


import '../classify.dart';
import '../main.dart';
import '../normalize.dart';
import '../notify.dart';
import '../theme.dart';
import '../types.dart';
import 'common.dart';
import 'detail.dart';
import 'settings.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with WidgetsBindingObserver, SingleTickerProviderStateMixin {
  late final TabController _tabController;
  bool _searchMode = false;
  String _query = '';
  final TextEditingController _searchCtl = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _tabController = TabController(length: 2, vsync: this);
    appState.addListener(_onStateChanged);
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybeOpenPending());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    appState.removeListener(_onStateChanged);
    _tabController.dispose();
    _searchCtl.dispose();
    super.dispose();
  }

  void _onStateChanged() {
    if (mounted) setState(() {});
    _maybeOpenPending();
  }

  void _maybeOpenPending() {
    final id = appState.pendingOpenId;
    if (id != null && mounted) {
      final item = appState.byId(id);
      appState.consumePendingOpen();
      if (item != null) {
        _openDetail(item);
      }
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // Re-read what the background check may have stored.
      appState.reloadFromStorage();
    }
  }

  void _openDetail(Item item) {
    appState.markRead(item);
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => DetailScreen(itemId: item.id)),
    );
  }

  Future<void> _sendTestNotification() async {
    final ok = await Notify.requestPermission();
    if (!mounted) return;
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Notification permission is off. Enable it in Android settings for DB Alert.')));
      return;
    }
    await Notify.showTest();
    if (mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Test notification sent.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final unread = appState.unreadCount;
    return Scaffold(
      appBar: AppBar(
        title: _searchMode
            ? TextField(
                controller: _searchCtl,
                autofocus: true,
                style: const TextStyle(color: Colors.white, fontSize: 16),
                cursorColor: Colors.white,
                decoration: const InputDecoration(
                  hintText: 'Search updates…',
                  hintStyle: TextStyle(color: Colors.white60),
                  border: InputBorder.none,
                ),
                onChanged: (v) => setState(() => _query = v),
              )
            : const Text('DB Alert'),
        actions: [
          IconButton(
            tooltip: _searchMode ? 'Close search' : 'Search',
            icon: Icon(_searchMode ? Icons.close : Icons.search),
            onPressed: () {
              setState(() {
                if (_searchMode) {
                  _searchCtl.clear();
                  _query = '';
                }
                _searchMode = !_searchMode;
              });
            },
          ),
          IconButton(
            tooltip: 'Check now',
            onPressed: appState.syncing ? null : () => appState.refresh(manual: true),
            icon: appState.syncing
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.white),
                  )
                : const Icon(Icons.refresh),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert),
            onSelected: (v) {
              switch (v) {
                case 'settings':
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const SettingsScreen()));
                  break;
                case 'test':
                  _sendTestNotification();
                  break;
                case 'markAllRead':
                  appState.markAllRead();
                  break;
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'settings', child: Text('Settings')),
              PopupMenuItem(value: 'test', child: Text('Send test notification')),
              PopupMenuItem(value: 'markAllRead', child: Text('Mark all as read')),
            ],
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          indicatorWeight: 3,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          tabs: [
            Tab(text: unread > 0 ? 'UPDATES ($unread)' : 'UPDATES'),
            const Tab(text: 'DONE'),
          ],
        ),
      ),
      body: Column(
        children: [
          if (!appState.config.isConfigured)
            NotConfiguredBanner(
              onOpenSettings: () => Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
            ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _UpdatesTab(
                  items: _filter(appState.activeItems),
                  onOpen: _openDetail,
                  onRefresh: () => appState.refresh(manual: true),
                  configured: appState.config.isConfigured,
                ),
                _UpdatesTab(
                  items: _filter(appState.doneItems),
                  onOpen: _openDetail,
                  onRefresh: () => appState.refresh(manual: true),
                  configured: appState.config.isConfigured,
                  doneTab: true,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  List<Item> _filter(List<Item> items) {
    if (_query.trim().isEmpty) return items;
    final q = _query.trim().toLowerCase();
    return items
        .where((it) =>
            it.title.toLowerCase().contains(q) ||
            it.body.toLowerCase().contains(q) ||
            it.type.toLowerCase().contains(q))
        .toList();
  }
}

/// One tab: day-grouped WhatsApp-style list.
class _UpdatesTab extends StatelessWidget {
  final List<Item> items;
  final void Function(Item) onOpen;
  final Future<void> Function() onRefresh;
  final bool configured;
  final bool doneTab;

  const _UpdatesTab({
    required this.items,
    required this.onOpen,
    required this.onRefresh,
    required this.configured,
    this.doneTab = false,
  });

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return RefreshIndicator(
        onRefresh: onRefresh,
        child: ListView(
          children: [
            const SizedBox(height: 120),
            EmptyState(
              icon: doneTab ? Icons.done_all : Icons.mark_chat_unread_outlined,
              title: doneTab ? 'Nothing marked done' : 'No updates yet',
              message: doneTab
                  ? 'Items you mark as done will be listed here with blue ticks.'
                  : configured
                      ? 'New items from your database will appear here automatically — and you will get a notification for each one.'
                      : 'Open the menu (⋮) → Settings to connect your Firebase database.',
            ),
          ],
        ),
      );
    }

    // Group by day (items are sorted newest-first).
    final groups = <String, List<Item>>{};
    for (final it in items) {
      final key = dayLabel(it.sortMs);
      groups.putIfAbsent(key, () => []).add(it);
    }

    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView.separated(
        itemCount: groups.length,
        separatorBuilder: (_, _) => const Divider(
            indent: 86, height: 1, thickness: 0.5, color: T.divider),
        itemBuilder: (context, g) {
          final entry = groups.entries.elementAt(g);
          final children = <Widget>[
            const SizedBox(height: 10),
            _DayChip(label: entry.key),
          ];
          for (final it in entry.value) {
            children.add(_Tile(item: it, onOpen: () => onOpen(it)));
          }
          children.add(const SizedBox(height: 6));
          return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children);
        },
      ),
    );
  }
}

class _DayChip extends StatelessWidget {
  final String label;
  const _DayChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: T.dateChipBg,
          border: Border.all(color: T.dateChipBorder),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          label.toUpperCase(),
          style: const TextStyle(
              fontSize: 11.5,
              fontWeight: FontWeight.w600,
              color: T.dateChipText,
              letterSpacing: 0.4),
        ),
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  final Item item;
  final VoidCallback onOpen;
  const _Tile({required this.item, required this.onOpen});

  @override
  Widget build(BuildContext context) {
    final style = classifyType(item.type);
    final done = appState.effectiveDone(item);
    final unread = appState.isUnread(item);
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
      leading: CircleAvatar(
        radius: 24,
        backgroundColor: Color(style.color),
        child: Text(style.emoji, style: const TextStyle(fontSize: 20)),
      ),
      title: Text(
        item.title,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          fontSize: 16,
          fontWeight: unread ? FontWeight.w700 : FontWeight.w500,
          color: T.textPrimary,
        ),
      ),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 2),
        child: Text(
          item.body.isEmpty ? '${style.label} update' : item.body,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 13.5, color: T.textSecondary),
        ),
      ),
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            item.timeMs != null ? timeLabel(item.timeMs!) : '',
            style: const TextStyle(fontSize: 11.5, color: T.textSecondary),
          ),
          const SizedBox(height: 4),
          if (done)
            const BlueTicks(size: 18)
          else if (unread)
            Container(
              width: 10,
              height: 10,
              decoration: const BoxDecoration(color: T.accent, shape: BoxShape.circle),
            ),
        ],
      ),
      onTap: onOpen,
    );
  }
}
