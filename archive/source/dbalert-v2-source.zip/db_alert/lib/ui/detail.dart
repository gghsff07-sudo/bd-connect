// Deep-dive detail view: full message in a chat bubble, type, time,
// document id, raw document inspector, and mark-as-done / mark-as-active.
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';


import '../classify.dart';
import '../main.dart';
import '../normalize.dart';
import '../theme.dart';
import '../types.dart';
import 'common.dart';

class DetailScreen extends StatefulWidget {
  final String itemId;
  const DetailScreen({super.key, required this.itemId});

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  @override
  void initState() {
    super.initState();
    appState.addListener(_onChange);
  }

  @override
  void dispose() {
    appState.removeListener(_onChange);
    super.dispose();
  }

  void _onChange() {
    if (mounted) setState(() {});
  }

  Future<void> _toggleDone() async {
    final item = appState.byId(widget.itemId);
    if (item == null) return;
    final done = appState.effectiveDone(item);
    final msg = await appState.markDone(item, !done);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
    }
  }

  void _showRaw() {
    final item = appState.byId(widget.itemId);
    if (item == null) return;
    final encoder = JsonEncoder.withIndent('  ');
    String pretty;
    try {
      pretty = encoder.convert(item.raw);
    } catch (_) {
      pretty = '${item.raw}';
    }
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        insetPadding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 8, 6),
              child: Row(
                children: [
                  const Expanded(
                    child: Text('Raw document',
                        style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
                  ),
                  IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.of(ctx).pop()),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(14),
                child: SelectableText(
                  pretty,
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 12.5, height: 1.45),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final item = appState.byId(widget.itemId);
    if (item == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Update')),
        body: const EmptyState(
            icon: Icons.search_off,
            title: 'Item not found',
            message: 'It may have been removed from the history.'),
      );
    }
    final style = classifyType(item.type);
    final done = appState.effectiveDone(item);

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(item.title,
                maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 1),
            Text('${style.emoji} ${style.label}',
                style: const TextStyle(fontSize: 12, color: Colors.white70)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Copy document id',
            icon: const Icon(Icons.copy, size: 20),
            onPressed: () {
              Clipboard.setData(ClipboardData(text: item.id));
              ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Document id copied.')));
            },
          ),
        ],
      ),
      body: Container(
        color: T.chatBg,
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
          children: [
            Center(
              child: Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: T.dateChipBg,
                  border: Border.all(color: T.dateChipBorder),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  dayLabel(item.sortMs).toUpperCase(),
                  style: const TextStyle(
                      fontSize: 11.5,
                      fontWeight: FontWeight.w600,
                      color: T.dateChipText,
                      letterSpacing: 0.4),
                ),
              ),
            ),
            // The message itself
            Bubble(
              color: T.bubbleIncoming,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SelectableText(
                    item.body.isEmpty ? '(no message content)' : item.body,
                    style: const TextStyle(fontSize: 15, height: 1.4, color: T.textPrimary),
                  ),
                  const SizedBox(height: 6),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          item.timeMs != null ? timeLabel(item.timeMs!) : '',
                          style: const TextStyle(fontSize: 11, color: T.textSecondary),
                        ),
                        if (done) ...[
                          const SizedBox(width: 4),
                          const BlueTicks(size: 14),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            // Type
            Bubble(
              color: Color(style.color).withValues(alpha: 0.12),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(style.emoji, style: const TextStyle(fontSize: 15)),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('TYPE',
                            style: TextStyle(
                                fontSize: 10, color: T.textSecondary, letterSpacing: 0.5)),
                        Text(
                          '${style.label}  (${item.type})',
                          style: const TextStyle(
                              fontSize: 13.5, fontWeight: FontWeight.w600, color: T.textPrimary),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            // Time + source + id
            Bubble(
              color: T.bubbleIncoming.withValues(alpha: 0.75),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _metaRow(Icons.schedule, fullTimeLabel(item.timeMs ?? item.sortMs)),
                  const SizedBox(height: 4),
                  _metaRow(Icons.cloud_outlined,
                      item.kind == DbKind.rtdb ? 'Realtime Database' : 'Firestore'),
                  const SizedBox(height: 4),
                  _metaRow(Icons.tag, 'Document id: ${item.id}'),
                ],
              ),
            ),
            const SizedBox(height: 10),
            // Status bubble
            Bubble(
              color: done ? const Color(0xFFE7F3FB) : const Color(0xFFE8F8EE),
              tailRight: true,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (done) ...[
                    const BlueTicks(size: 16),
                    const SizedBox(width: 6),
                    const Text('Marked as done',
                        style: TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w600,
                            color: T.textPrimary)),
                  ] else ...[
                    const Icon(Icons.radio_button_checked,
                        size: 14, color: T.accentPressed),
                    const SizedBox(width: 6),
                    const Text('Active',
                        style: TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w600,
                            color: T.textPrimary)),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 16),
            Center(
              child: TextButton.icon(
                onPressed: _showRaw,
                icon: const Icon(Icons.data_object, size: 18),
                label: const Text('Raw document'),
              ),
            ),
            const SizedBox(height: 80),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: SizedBox(
            height: 46,
            child: FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: done ? Colors.white : T.accent,
                foregroundColor: done ? T.header : Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                  side: done ? const BorderSide(color: T.header, width: 1.2) : BorderSide.none,
                ),
              ),
              onPressed: _toggleDone,
              icon: done
                  ? const Icon(Icons.refresh, size: 20)
                  : const Icon(Icons.done_all, size: 20),
              label: Text(
                done ? 'Mark as active' : 'Mark as done',
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _metaRow(IconData icon, String text) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 14, color: T.textSecondary),
        const SizedBox(width: 6),
        Expanded(
          child: Text(
            text,
            style: const TextStyle(fontSize: 12.5, color: T.textPrimary),
            overflow: TextOverflow.ellipsis,
            maxLines: 2,
          ),
        ),
      ],
    );
  }
}
