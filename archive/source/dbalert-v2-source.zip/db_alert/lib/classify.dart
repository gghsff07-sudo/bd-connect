// Classifies a raw "type" value into a notification style.
// Each class gets its own Android notification channel with its own
// importance, vibration pattern and color, plus a distinct emoji
// (ported 1:1 from the v1.1.0 Expo app).

class TypeStyle {
  final String key;
  final String label;
  final String emoji;
  final int color; // 0xAARRGGBB
  final int importance; // flutter_local_notifications importance value (3 default, 4 high, 5 max)
  final List<int> vibration; // ms pattern
  final bool bypassDnd;
  final String channelName;

  const TypeStyle({
    required this.key,
    required this.label,
    required this.emoji,
    required this.color,
    required this.importance,
    required this.vibration,
    required this.bypassDnd,
    required this.channelName,
  });
}

class _Classifier extends TypeStyle {
  final List<String> keywords;
  const _Classifier({
    required super.key,
    required super.label,
    required super.emoji,
    required super.color,
    required super.importance,
    required super.vibration,
    required super.bypassDnd,
    required super.channelName,
    required this.keywords,
  });
}

const List<_Classifier> _classifiers = [
  _Classifier(
    key: 'critical',
    label: 'Critical',
    emoji: '🚨',
    color: 0xFFE53935,
    importance: 5,
    vibration: [0, 700, 300, 700, 300, 700],
    bypassDnd: true,
    channelName: 'Critical alerts',
    keywords: [
      'critical', 'urgent', 'emergency', 'severe', 'fail', 'failed', 'failure',
      'error', 'down', 'outage', 'alarm', 'fraud', 'suspicious', 'blocked',
      'overdue', 'cancel',
    ],
  ),
  _Classifier(
    key: 'warning',
    label: 'Warning',
    emoji: '⚠️',
    color: 0xFFFF8C00,
    importance: 4,
    vibration: [0, 400, 200, 400, 200, 400],
    bypassDnd: false,
    channelName: 'Warnings',
    keywords: [
      'warning', 'caution', 'alert', 'risk', 'attention', 'expiring', 'expire',
      'expired', 'reminder', 'low', 'limit', 'retry', 'pending',
    ],
  ),
  _Classifier(
    key: 'payment',
    label: 'Payment',
    emoji: '💰',
    color: 0xFF25D366,
    importance: 4,
    vibration: [0, 300, 150, 300],
    bypassDnd: false,
    channelName: 'Payment updates',
    keywords: [
      'payment', 'paid', 'money', 'transaction', 'invoice', 'bill', 'refund',
      'cash', 'salary', 'credit', 'debit', 'withdraw', 'fee', 'charge',
      'subscription', 'topup', 'top-up', 'balance',
    ],
  ),
  _Classifier(
    key: 'order',
    label: 'Order',
    emoji: '📦',
    color: 0xFF128C7E,
    importance: 3,
    vibration: [0, 250],
    bypassDnd: false,
    channelName: 'Order updates',
    keywords: [
      'order', 'booking', 'reservation', 'delivery', 'shipping', 'dispatch',
      'package', 'shipment', 'pickup', 'appointment',
    ],
  ),
  _Classifier(
    key: 'info',
    label: 'Info',
    emoji: 'ℹ️',
    color: 0xFF075E54,
    importance: 3,
    vibration: [0, 250],
    bypassDnd: false,
    channelName: 'Info updates',
    keywords: [
      'info', 'information', 'notice', 'update', 'news', 'general', 'message',
      'system', 'success', 'complete', 'completed', 'sync', 'report',
    ],
  ),
];

const TypeStyle kDefaultStyle = TypeStyle(
  key: 'general',
  label: 'General',
  emoji: '🔔',
  color: 0xFF128C7E,
  importance: 3,
  vibration: [0, 250],
  bypassDnd: false,
  channelName: 'General updates',
);

const TypeStyle kTestStyle = TypeStyle(
  key: 'test',
  label: 'Test',
  emoji: '🔔',
  color: 0xFF075E54,
  importance: 3,
  vibration: [0, 250],
  bypassDnd: false,
  channelName: 'Test notifications',
);

// All styles that need a notification channel created.
const List<TypeStyle> kAllStyles = [
  ..._classifiers,
  kDefaultStyle,
  kTestStyle,
];

final Map<String, TypeStyle> _cache = {};

/// Returns the notification style for a raw type string (case-insensitive,
/// keyword containment — same behavior as v1.1.0).
TypeStyle classifyType(String? rawType) {
  final t = (rawType ?? '').trim().toLowerCase();
  if (t.isEmpty) return kDefaultStyle;
  final hit = _cache[t];
  if (hit != null) return hit;
  TypeStyle style = kDefaultStyle;
  for (final c in _classifiers) {
    if (c.keywords.any((kw) => t.contains(kw))) {
      style = TypeStyle(
        key: c.key,
        label: c.label,
        emoji: c.emoji,
        color: c.color,
        importance: c.importance,
        vibration: c.vibration,
        bypassDnd: c.bypassDnd,
        channelName: c.channelName,
      );
      break;
    }
  }
  _cache[t] = style;
  return style;
}

/// Channel id for a style.
String channelIdFor(TypeStyle s) => 'dbalert-${s.key}';
