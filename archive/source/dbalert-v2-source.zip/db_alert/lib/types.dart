// Shared types for DB Alert (ported from v1.1.0).

enum DbKind { firestore, rtdb }

DbKind dbKindFromString(String? s) => s == 'rtdb' ? DbKind.rtdb : DbKind.firestore;

String dbKindToString(DbKind k) => k == DbKind.rtdb ? 'rtdb' : 'firestore';

// User-editable configuration, stored in SharedPreferences.
class AppConfig {
  DbKind kind;
  String projectId;
  String apiKey;
  String path;
  String dbUrl;
  String authEmail;
  String authPassword;

  AppConfig({
    this.kind = DbKind.firestore,
    this.projectId = '',
    this.apiKey = '',
    this.path = 'notifications',
    this.dbUrl = '',
    this.authEmail = '',
    this.authPassword = '',
  });

  bool get isConfigured {
    if (kind == DbKind.rtdb) {
      return dbUrl.trim().isNotEmpty || projectId.trim().isNotEmpty;
    }
    return projectId.trim().isNotEmpty && apiKey.trim().isNotEmpty;
  }

  AppConfig copyWith({
    DbKind? kind,
    String? projectId,
    String? apiKey,
    String? path,
    String? dbUrl,
    String? authEmail,
    String? authPassword,
  }) =>
      AppConfig(
        kind: kind ?? this.kind,
        projectId: projectId ?? this.projectId,
        apiKey: apiKey ?? this.apiKey,
        path: path ?? this.path,
        dbUrl: dbUrl ?? this.dbUrl,
        authEmail: authEmail ?? this.authEmail,
        authPassword: authPassword ?? this.authPassword,
      );

  Map<String, dynamic> toMap() => {
        'kind': dbKindToString(kind),
        'projectId': projectId,
        'apiKey': apiKey,
        'path': path,
        'dbUrl': dbUrl,
        'authEmail': authEmail,
        'authPassword': authPassword,
      };

  factory AppConfig.fromMap(Map<String, dynamic> m) => AppConfig(
        kind: dbKindFromString(m['kind'] as String?),
        projectId: (m['projectId'] as String?) ?? '',
        apiKey: (m['apiKey'] as String?) ?? '',
        path: (m['path'] as String?) ?? 'notifications',
        dbUrl: (m['dbUrl'] as String?) ?? '',
        authEmail: (m['authEmail'] as String?) ?? '',
        authPassword: (m['authPassword'] as String?) ?? '',
      );
}

/// One normalized item from the database, shown in history.
class Item {
  final String id;
  final String title;
  final String body;
  final String type;
  final int? timeMs;
  final int sortMs;
  final Map<String, dynamic> raw;
  final bool remoteDone;
  final String? statusField;
  final DbKind kind;

  Item({
    required this.id,
    required this.title,
    required this.body,
    required this.type,
    required this.timeMs,
    required this.sortMs,
    required this.raw,
    required this.remoteDone,
    required this.statusField,
    required this.kind,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'body': body,
        'type': type,
        'timeMs': timeMs,
        'sortMs': sortMs,
        'raw': raw,
        'remoteDone': remoteDone,
        'statusField': statusField,
        'kind': dbKindToString(kind),
      };

  factory Item.fromMap(Map<String, dynamic> m) => Item(
        id: (m['id'] as String?) ?? '',
        title: (m['title'] as String?) ?? 'New update',
        body: (m['body'] as String?) ?? '',
        type: (m['type'] as String?) ?? 'general',
        timeMs: m['timeMs'] as int?,
        sortMs: (m['sortMs'] as int?) ?? 0,
        raw: (m['raw'] as Map?)?.cast<String, dynamic>() ?? {},
        remoteDone: (m['remoteDone'] as bool?) ?? false,
        statusField: m['statusField'] as String?,
        kind: dbKindFromString(m['kind'] as String?),
      );
}

/// Result of one background/manual check (shown in Diagnostics).
class CheckResultMeta {
  final bool ok;
  final int at;
  final String? error;
  final int? newCount;

  CheckResultMeta({required this.ok, required this.at, this.error, this.newCount});

  Map<String, dynamic> toMap() => {'ok': ok, 'at': at, 'error': error, 'newCount': newCount};

  factory CheckResultMeta.fromMap(Map<String, dynamic> m) => CheckResultMeta(
        ok: (m['ok'] as bool?) ?? false,
        at: (m['at'] as int?) ?? 0,
        error: m['error'] as String?,
        newCount: m['newCount'] as int?,
      );
}
