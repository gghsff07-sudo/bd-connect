// WhatsApp-inspired visual theme (ported from the v1.1.0 Expo app).
import 'package:flutter/material.dart';

class T {
  // classic WhatsApp palette
  static const Color header = Color(0xFF075E54); // teal green app bar
  static const Color headerDark = Color(0xFF054D44); // status bar tint
  static const Color accent = Color(0xFF25D366); // light green (badges, buttons)
  static const Color accentPressed = Color(0xFF1DA85A);
  static const Color listBg = Color(0xFFFFFFFF);
  static const Color chatBg = Color(0xFFECE5DD); // classic chat wallpaper
  static const Color bubbleIncoming = Color(0xFFFFFFFF);
  static const Color dateChipBg = Color(0xFFFFFFFF);
  static const Color dateChipBorder = Color(0xFFE9EDEF);
  static const Color dateChipText = Color(0xFF54656F);
  static const Color textPrimary = Color(0xFF111B21);
  static const Color textSecondary = Color(0xFF667781);
  static const Color divider = Color(0xFFF0F0F0);
  static const Color ticksBlue = Color(0xFF34B7F1);
  static const Color danger = Color(0xFFE53935);
  static const Color warn = Color(0xFFF59E0B);
  static const Color inputBg = Color(0xFFF0F2F5);
  static const Color cardBorder = Color(0xFFE9EDEF);
}
