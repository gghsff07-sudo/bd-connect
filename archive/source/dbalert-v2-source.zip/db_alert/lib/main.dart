// DB Alert v2 — WhatsApp-style database monitor (Flutter rebuild).
//
// Crash-proof by design (that was the whole point of the rewrite):
// - no native Firebase SDK; the database is read over plain HTTPS
// - every init step is wrapped in try/catch
// - widget build errors render a fallback screen instead of crashing
// - WorkManager checks the database roughly every 15 minutes while closed
import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'app_state.dart';
import 'notify.dart';
import 'poll.dart';
import 'theme.dart';
import 'ui/home.dart';

final AppState appState = AppState();

Future<void> main() async {
  await runZonedGuarded(() async {
    WidgetsFlutterBinding.ensureInitialized();

    // Never show a grey crash screen — render a friendly error widget instead.
    ErrorWidget.builder = (FlutterErrorDetails details) {
      debugPrint('Widget error: ${details.exception}');
      return Material(
        color: T.listBg,
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Icon(Icons.error_outline, size: 48, color: T.textSecondary),
                SizedBox(height: 12),
                Text('Something went wrong showing this screen.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: T.textSecondary)),
              ],
            ),
          ),
        ),
      );
    };
    PlatformDispatcher.instance.onError = (e, s) {
      debugPrint('Platform error: $e');
      return true;
    };

    try {
      await appState.load();
    } catch (e) {
      debugPrint('state load failed: $e');
    }
    try {
      await Notify.ensureInit();
    } catch (e) {
      debugPrint('notify init failed: $e');
    }
    try {
      appState.notifPermission = await Notify.requestPermission();
    } catch (e) {
      debugPrint('permission request failed: $e');
    }
    try {
      Poller.registerBackground();
    } catch (e) {
      debugPrint('workmanager failed: $e');
    }
    Poller.startInAppTimer();

    Notify.onOpenItem = (itemId) {
      appState.requestOpen(itemId);
    };

    runApp(const DBAlertApp());

    // Launched from a notification tap (cold start)?
    try {
      final payload = await Notify.launchPayload();
      if (payload != null && payload.isNotEmpty) {
        appState.requestOpen(payload);
      }
    } catch (e) {
      debugPrint('launch payload failed: $e');
    }

    // Fresh check every time the app opens.
    unawaited(appState.refresh());
  }, (e, s) {
    debugPrint('Uncaught zone error: $e');
  });
}

class DBAlertApp extends StatelessWidget {
  const DBAlertApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DB Alert',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: T.header).copyWith(
          primary: T.header,
          secondary: T.accent,
        ),
        scaffoldBackgroundColor: T.listBg,
        appBarTheme: const AppBarTheme(
          backgroundColor: T.header,
          foregroundColor: Colors.white,
          elevation: 0,
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        dividerColor: T.divider,
        splashColor: T.divider,
      ),
      home: const HomeScreen(),
    );
  }
}
