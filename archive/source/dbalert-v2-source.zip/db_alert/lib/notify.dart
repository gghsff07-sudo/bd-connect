// Notifications via flutter_local_notifications.
// One Android channel per type class (Critical / Warning / Payment / Order /
// Info / General / Test), each with its own importance, vibration and color.
// Every call is defensive: failures are swallowed, never crash the app.
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import 'classify.dart';
import 'types.dart';

class Notify {
  static final FlutterLocalNotificationsPlugin plugin =
      FlutterLocalNotificationsPlugin();
  static bool _initDone = false;

  /// Set by main() — called when the user taps a notification (payload = item id).
  static void Function(String itemId)? onOpenItem;

  static AndroidFlutterLocalNotificationsPlugin? get _android =>
      plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

  static Future<void> ensureInit() async {
    if (_initDone) return;
    try {
      const settings = InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_notification'),
      );
      await plugin.initialize(
        settings,
        onDidReceiveNotificationResponse: (NotificationResponse response) {
          final payload = response.payload;
          if (payload != null && payload.isNotEmpty) {
            final cb = onOpenItem;
            if (cb != null) cb(payload);
          }
        },
      );
      await _createChannels();
      _initDone = true;
    } catch (e) {
      debugPrint('Notify.ensureInit failed: $e');
    }
  }

  static Future<void> _createChannels() async {
    final android = _android;
    if (android == null) return;
    for (final s in kAllStyles) {
      try {
        await android.createNotificationChannel(AndroidNotificationChannel(
          channelIdFor(s),
          s.channelName,
          description: 'DB Alert ${s.label} notifications',
          importance: _imp(s.importance),
          enableVibration: true,
          vibrationPattern: Int64List.fromList(s.vibration),
          ledColor: Color(s.color),
          showBadge: true,
        ));
      } catch (e) {
        debugPrint('channel create failed for ${s.key}: $e');
      }
    }
  }

  static Importance _imp(int i) {
    switch (i) {
      case 5:
        return Importance.max;
      case 4:
        return Importance.high;
      default:
        return Importance.defaultImportance;
    }
  }

  static Priority _prio(int i) {
    switch (i) {
      case 5:
        return Priority.max;
      case 4:
        return Priority.high;
      default:
        return Priority.defaultPriority;
    }
  }

  /// Asks for the POST_NOTIFICATIONS permission (Android 13+).
  /// Returns true when notifications can be shown.
  static Future<bool> requestPermission() async {
    try {
      await ensureInit();
      final android = _android;
      if (android == null) return true;
      final granted = await android.requestNotificationsPermission();
      return granted ?? await areNotificationsEnabled();
    } catch (e) {
      debugPrint('Notify.requestPermission failed: $e');
      return false;
    }
  }

  static Future<bool> areNotificationsEnabled() async {
    try {
      final android = _android;
      if (android == null) return true;
      return await android.areNotificationsEnabled() ?? true;
    } catch (_) {
      return true;
    }
  }

  /// Stable non-negative notification id for an item id.
  static int _notifId(String itemId) {
    var h = 0;
    for (final c in itemId.codeUnits) {
      h = (h * 31 + c) & 0x7fffffff;
    }
    return h == 0 ? 1 : h;
  }

  /// Shows a notification for one new item, styled by its type.
  static Future<void> showItem(Item item) async {
    try {
      await ensureInit();
      final style = classifyType(item.type);
      final details = AndroidNotificationDetails(
        channelIdFor(style),
        style.channelName,
        channelDescription: 'DB Alert ${style.label} notifications',
        importance: _imp(style.importance),
        priority: _prio(style.importance),
        icon: '@mipmap/ic_notification',
        color: Color(style.color),
        vibrationPattern: Int64List.fromList(style.vibration),
        autoCancel: true,
        groupKey: 'dbalert.${style.key}',
        styleInformation: BigTextStyleInformation(
          item.body.isEmpty ? '${style.label} update' : item.body,
        ),
      );
      await plugin.show(
        _notifId(item.id),
        '${style.emoji} ${item.title}',
        item.body.isEmpty ? '${style.label} update in your database' : item.body,
        NotificationDetails(android: details),
        payload: item.id,
      );
    } catch (e) {
      debugPrint('Notify.showItem failed: $e');
    }
  }

  /// Shown when more than [Notify.maxPerCheck] new items arrived at once.
  static const int maxPerCheck = 8;

  static Future<void> showSummary(int extraCount) async {
    try {
      await ensureInit();
      const style = kDefaultStyle;
      final details = AndroidNotificationDetails(
        channelIdFor(style),
        style.channelName,
        channelDescription: 'DB Alert General notifications',
        importance: _imp(style.importance),
        priority: _prio(style.importance),
        icon: '@mipmap/ic_notification',
        color: Color(style.color),
        autoCancel: true,
        groupKey: 'dbalert.${style.key}',
      );
      await plugin.show(
        999999,
        '${style.emoji} $extraCount more new updates',
        'Open DB Alert to see everything that arrived.',
        NotificationDetails(android: details),
      );
    } catch (e) {
      debugPrint('Notify.showSummary failed: $e');
    }
  }

  /// Shows a test notification from Settings.
  static Future<void> showTest() async {
    try {
      await ensureInit();
      const style = kTestStyle;
      final details = AndroidNotificationDetails(
        channelIdFor(style),
        style.channelName,
        channelDescription: 'DB Alert test notifications',
        importance: _imp(style.importance),
        priority: _prio(style.importance),
        icon: '@mipmap/ic_notification',
        color: Color(style.color),
        autoCancel: true,
      );
      await plugin.show(
        999998,
        '${style.emoji} Test notification',
        'Notifications are working. This is how DB Alert will alert you.',
        NotificationDetails(android: details),
      );
    } catch (e) {
      debugPrint('Notify.showTest failed: $e');
    }
  }

  /// Cancels the active notification of an item (e.g. when marked done).
  static Future<void> cancelFor(Item item) async {
    try {
      await plugin.cancel(_notifId(item.id));
    } catch (_) {}
  }

  /// Payload when the app was launched from a notification (cold start).
  static Future<String?> launchPayload() async {
    try {
      final details = await plugin.getNotificationAppLaunchDetails();
      if (details?.didNotificationLaunchApp == true) {
        return details?.notificationResponse?.payload;
      }
      return null;
    } catch (_) {
      return null;
    }
  }
}
