#!/usr/bin/env python3
"""Generate WhatsApp-green app icon set (chat bubble + bell) for DB Alert."""
from PIL import Image, ImageDraw

S = 1024
GREEN = (0, 128, 105, 255)        # #008069 WhatsApp teal green
WHITE = (255, 255, 255, 255)


def rounded(draw, box, r, fill):
    draw.rounded_rectangle(box, radius=r, fill=fill)


def draw_bubble_with_bell(img, scale=1.0):
    """Draw a white chat bubble containing a green bell, centered."""
    d = ImageDraw.Draw(img)
    w, h = img.size
    cx, cy = w / 2, h / 2

    # --- chat bubble (white) ---
    bw, bh = int(560 * scale), int(460 * scale)   # bubble size
    bx0, by0 = cx - bw / 2, cy - bh / 2
    bx1, by1 = cx + bw / 2, cy + bh / 2
    # tail first (polygon under bubble), pointing down-left like WhatsApp
    tail = [(bx0 + bw * 0.16, by1 - 6 * scale), (bx0 + bw * 0.34, by1 - 6 * scale),
            (bx0 + bw * 0.10, by1 + 90 * scale)]
    d.polygon(tail, fill=WHITE)
    rounded(d, [bx0, by0, bx1, by1], int(120 * scale), WHITE)

    # --- bell inside the bubble (green) ---
    s = scale
    # bell body: dome (pieslice) + flare (polygon)
    bellw, bellh = int(240 * s), int(200 * s)
    bcx, bcy = cx, cy - int(30 * s)
    # dome
    d.pieslice([bcx - bellw / 2, bcy - bellh / 2, bcx + bellw / 2, bcy + bellh / 2],
               180, 360, fill=GREEN)
    # flare trapezoid below dome
    d.polygon([(bcx - bellw / 2, bcy), (bcx + bellw / 2, bcy),
               (bcx + bellw / 2 + 46 * s, bcy + 110 * s), (bcx - bellw / 2 - 46 * s, bcy + 110 * s)],
              fill=GREEN)
    # clapper
    d.ellipse([bcx - 34 * s, bcy + 118 * s, bcx + 34 * s, bcy + 180 * s], fill=GREEN)
    # handle on top
    d.rounded_rectangle([bcx - 22 * s, bcy - bellh / 2 - 52 * s, bcx + 22 * s, bcy - bellh / 2],
                        radius=int(22 * s), fill=GREEN)


def make_icon():
    img = Image.new("RGBA", (S, S), GREEN)
    # subtle darker circle backdrop for depth
    d = ImageDraw.Draw(img)
    d.ellipse([S * 0.06, S * 0.06, S * 0.94, S * 0.94], fill=(0, 118, 97, 255))
    draw_bubble_with_bell(img)
    return img


def make_foreground():
    """Adaptive icon foreground: transparent bg, icon art within 66% safe zone."""
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    draw_bubble_with_bell(img, scale=0.62)
    return img


def make_splash():
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    draw_bubble_with_bell(img, scale=0.55)
    return img


icon = make_icon()
icon.save("/home/z/my-project/app/assets/icon.png")

fg = make_foreground()
fg.save("/home/z/my-project/app/assets/android-icon-foreground.png")
fg.save("/home/z/my-project/app/assets/android-icon-monochrome.png")

# background for adaptive icon (solid green)
bg = Image.new("RGBA", (S, S), GREEN)
bg.save("/home/z/my-project/app/assets/android-icon-background.png")

make_splash().save("/home/z/my-project/app/assets/splash-icon.png")

# favicon 48
make_icon().resize((48, 48), Image.LANCZOS).save("/home/z/my-project/app/assets/favicon.png")

# verification: composite adaptive icon preview (fg over bg) for a visual check
import os
os.makedirs("/tmp/render", exist_ok=True)
preview = bg.copy()
preview.alpha_composite(fg)
preview.convert("RGB").resize((256, 256)).save("/tmp/render/icon_preview.png")
print("icons generated OK")
