/** Settings: connect your Firebase database, test it, diagnostics. */
import React, { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';
import { AppConfig } from '../types';
import { testConnection } from '../lib/firebase-rest';
import { postTestNotification } from '../lib/notify';
import { THEME } from '../theme';
import { AppBar, Field } from './common';

interface Props {
  initial: AppConfig;
  diagnostics: {
    taskRegistered: boolean;
    items: number;
    unread: number;
    done: number;
    seen: number;
    lastResult: { ok: boolean; at: number; error?: string } | null;
  } | null;
  onSave: (cfg: AppConfig) => Promise<void>;
  onReset: () => void;
  onReloadDiagnostics: () => void;
}

export default function SettingsScreen(props: Props) {
  const [cfg, setCfg] = useState<AppConfig>({ ...props.initial });
  const [testing, setTesting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);

  const set = (patch: Partial<AppConfig>) => setCfg((c) => ({ ...c, ...patch }));

  const runTest = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const r = await testConnection(cfg);
      setTestResult({ ok: r.ok, message: r.message });
    } catch (e) {
      setTestResult({ ok: false, message: e instanceof Error ? e.message : String(e) });
    } finally {
      setTesting(false);
    }
  };

  const save = async () => {
    setSaving(true);
    try {
      await props.onSave(cfg);
    } finally {
      setSaving(false);
    }
  };

  const sendTestNotification = async () => {
    try {
      const perm = await Notifications.requestPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Notifications blocked', 'Enable notifications for DB Alert in Android settings, then try again.');
        return;
      }
      await postTestNotification();
    } catch (e) {
      Alert.alert('Could not send', e instanceof Error ? e.message : String(e));
    }
  };

  const diag = props.diagnostics;

  return (
    <View style={styles.root}>
      <AppBar title="Settings" onBack={props.onReloadDiagnostics} />
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.sectionTitle}>CONNECT YOUR DATABASE</Text>
        <Text style={styles.help}>
          DB Alert reads your Firebase database directly. Paste your project details here - no
          Google services file or account needed on the phone.
        </Text>

        {/* database type */}
        <Text style={styles.label}>DATABASE TYPE</Text>
        <View style={styles.segment}>
          <SegBtn label="Firestore" active={cfg.kind === 'firestore'} onPress={() => set({ kind: 'firestore' })} />
          <SegBtn label="Realtime DB" active={cfg.kind === 'rtdb'} onPress={() => set({ kind: 'rtdb' })} />
        </View>

        <Field
          label="Project ID"
          value={cfg.projectId}
          onChangeText={(t) => set({ projectId: t })}
          placeholder="my-project-123"
          hint="Firebase console > Project settings > General > Project ID"
        />
        <Field
          label="Web API key"
          value={cfg.apiKey}
          onChangeText={(t) => set({ apiKey: t })}
          placeholder="AIza..."
          hint="Firebase console > Project settings > General > Web API key"
        />
        {cfg.kind === 'firestore' ? (
          <Field
            label="Collection"
            value={cfg.path}
            onChangeText={(t) => set({ path: t })}
            placeholder="notifications"
            hint="Firestore collection name. Sub-collections work too: users/me/notifications"
          />
        ) : (
          <>
            <Field
              label="Database URL"
              value={cfg.dbUrl}
              onChangeText={(t) => set({ dbUrl: t })}
              placeholder={`https://${cfg.projectId || 'my-project'}-default-rtdb.firebaseio.com`}
              hint="Optional - filled automatically from the project ID when empty"
            />
            <Field
              label="Path"
              value={cfg.path}
              onChangeText={(t) => set({ path: t })}
              placeholder="notifications"
              hint="Realtime Database node path"
            />
          </>
        )}

        <Text style={styles.sectionTitle}>SIGN-IN (OPTIONAL)</Text>
        <Text style={styles.help}>
          Only needed if your database rules require an authenticated user. Uses plain REST sign-in.
        </Text>
        <Field
          label="Email"
          value={cfg.authEmail}
          onChangeText={(t) => set({ authEmail: t })}
          placeholder="user@example.com"
          keyboardType="email-address"
        />
        <Field label="Password" value={cfg.authPassword} onChangeText={(t) => set({ authPassword: t })} placeholder="••••••••" secure />

        {/* actions */}
        <View style={styles.buttonRow}>
          <TouchableOpacity style={[styles.btn, styles.btnOutline]} onPress={runTest} disabled={testing}>
            {testing ? <ActivityIndicator color={THEME.header} size="small" /> : <Text style={styles.btnOutlineText}>Test connection</Text>}
          </TouchableOpacity>
          <TouchableOpacity style={[styles.btn, styles.btnFill]} onPress={save} disabled={saving}>
            {saving ? <ActivityIndicator color="#fff" size="small" /> : <Text style={styles.btnFillText}>Save & activate</Text>}
          </TouchableOpacity>
        </View>

        {testResult ? (
          <View style={[styles.testBox, { backgroundColor: testResult.ok ? '#E9F7EF' : '#FDECEA' }]}>
            <Text style={[styles.testText, { color: testResult.ok ? '#1B7A4A' : THEME.danger }]}>{testResult.message}</Text>
          </View>
        ) : null}

        <Text style={styles.sectionTitle}>HOW IT WORKS</Text>
        <View style={styles.card}>
          <Bullet text="Checks your database every 15 minutes, even when the app is closed (Android may delay checks to save battery)." />
          <Bullet text="Each new entry triggers a notification styled by its type: critical, warning, payment, order or info." />
          <Bullet text="Title, message, type and time are detected from common field names (title/body/message, type/category, createdAt/timestamp...)." />
          <Bullet text="Mark as done saves on this phone and also tries to write status=done back to the database." />
        </View>

        <Text style={styles.sectionTitle}>NOTIFICATIONS</Text>
        <TouchableOpacity style={[styles.btn, styles.btnOutline]} onPress={sendTestNotification}>
          <Text style={styles.btnOutlineText}>Send a test notification</Text>
        </TouchableOpacity>

        <Text style={styles.sectionTitle}>DIAGNOSTICS</Text>
        <View style={styles.card}>
          <DiagRow label="Background polling (15 min)" value={diag ? (diag.taskRegistered ? 'Active' : 'Not active') : '...'} good={diag?.taskRegistered} />
          <DiagRow
            label="Last check"
            value={diag?.lastResult ? (diag.lastResult.ok ? `OK (${new Date(diag.lastResult.at).toLocaleTimeString()})` : 'Failed') : 'Not run yet'}
            good={diag?.lastResult?.ok}
          />
          {diag?.lastResult && !diag.lastResult.ok && diag.lastResult.error ? (
            <Text style={styles.diagError}>{diag.lastResult.error}</Text>
          ) : null}
          <DiagRow label="Updates in history" value={diag ? String(diag.items - diag.done) : '...'} />
          <DiagRow label="Marked done" value={diag ? String(diag.done) : '...'} />
          <DiagRow label="Unread" value={diag ? String(diag.unread) : '...'} />
          <DiagRow label="Already seen (no re-alert)" value={diag ? String(diag.seen) : '...'} />
          <DiagRow label="Version" value={Constants.expoConfig?.version ?? '1.1.0'} />
        </View>

        <TouchableOpacity
          style={[styles.btn, styles.btnDanger]}
          onPress={() =>
            Alert.alert('Reset app data?', 'This clears your settings, history and all marks. It does not touch your database.', [
              { text: 'Cancel', style: 'cancel' },
              { text: 'Reset', style: 'destructive', onPress: props.onReset },
            ])
          }
        >
          <Text style={styles.btnDangerText}>Reset app data</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

function SegBtn({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return (
    <TouchableOpacity style={[styles.segBtn, active && styles.segBtnActive]} onPress={onPress}>
      <Text style={[styles.segText, active && styles.segTextActive]}>{label}</Text>
    </TouchableOpacity>
  );
}

function Bullet({ text }: { text: string }) {
  return (
    <View style={styles.bulletRow}>
      <View style={styles.bulletDot} />
      <Text style={styles.bulletText}>{text}</Text>
    </View>
  );
}

function DiagRow({ label, value, good }: { label: string; value: string; good?: boolean }) {
  return (
    <View style={styles.diagRow}>
      <Text style={styles.diagLabel}>{label}</Text>
      <Text
        style={[
          styles.diagValue,
          good === true ? { color: '#1B7A4A', fontWeight: '700' } : null,
          good === false ? { color: THEME.danger, fontWeight: '700' } : null,
        ]}
      >
        {value}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: THEME.listBg },
  content: { padding: 16, paddingBottom: 50 },
  sectionTitle: { color: THEME.header, fontSize: 12.5, fontWeight: '800', letterSpacing: 0.6, marginTop: 22, marginBottom: 8 },
  label: { color: THEME.textSecondary, fontSize: 12, fontWeight: '700', marginBottom: 6 },
  help: { color: THEME.textSecondary, fontSize: 13.5, lineHeight: 19, marginBottom: 14 },
  segment: { flexDirection: 'row', backgroundColor: THEME.inputBg, borderRadius: 10, padding: 3, marginBottom: 16 },
  segBtn: { flex: 1, paddingVertical: 9, borderRadius: 8, alignItems: 'center' },
  segBtnActive: { backgroundColor: '#fff', elevation: 2 },
  segText: { color: THEME.textSecondary, fontSize: 14.5, fontWeight: '600' },
  segTextActive: { color: THEME.header, fontWeight: '700' },
  buttonRow: { flexDirection: 'row', gap: 10, marginTop: 6 },
  btn: { flex: 1, borderRadius: 12, paddingVertical: 13, alignItems: 'center', justifyContent: 'center' },
  btnOutline: { backgroundColor: '#fff', borderWidth: 1.5, borderColor: THEME.header },
  btnFill: { backgroundColor: THEME.accent },
  btnDanger: { backgroundColor: '#fff', borderWidth: 1.5, borderColor: THEME.danger, marginTop: 22 },
  btnOutlineText: { color: THEME.header, fontSize: 15, fontWeight: '700' },
  btnFillText: { color: '#fff', fontSize: 15, fontWeight: '700' },
  btnDangerText: { color: THEME.danger, fontSize: 15, fontWeight: '700' },
  testBox: { borderRadius: 10, padding: 12, marginTop: 12 },
  testText: { fontSize: 13.5, lineHeight: 19 },
  card: { backgroundColor: '#fff', borderRadius: 12, padding: 14, elevation: 1.5 },
  bulletRow: { flexDirection: 'row', marginBottom: 9 },
  bulletDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: THEME.accent, marginTop: 6, marginRight: 10 },
  bulletText: { color: THEME.textPrimary, fontSize: 13.5, lineHeight: 19, flex: 1 },
  diagRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6 },
  diagLabel: { color: THEME.textSecondary, fontSize: 14 },
  diagValue: { color: THEME.textPrimary, fontSize: 14, fontWeight: '600' },
  diagError: { color: THEME.danger, fontSize: 12.5, lineHeight: 18, marginTop: 4 },
});
