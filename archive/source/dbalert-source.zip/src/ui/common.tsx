/** Small shared UI pieces styled after WhatsApp (classic Android look). */
import React from 'react';
import { StatusBar, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { THEME } from '../theme';
import { TypeStyle } from '../lib/classify';

export function topInset(): number {
  return StatusBar.currentHeight ?? 24;
}

/** Green app bar with optional back button and right actions. */
export function AppBar({
  title,
  onBack,
  right,
}: {
  title: string;
  onBack?: () => void;
  right?: React.ReactNode;
}) {
  return (
    <View style={[styles.bar, { paddingTop: topInset() }]}>
      {onBack ? (
        <TouchableOpacity style={styles.backBtn} onPress={onBack} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Text style={styles.backIcon}>‹</Text>
        </TouchableOpacity>
      ) : null}
      <Text style={styles.barTitle} numberOfLines={1}>
        {title}
      </Text>
      <View style={styles.right}>{right}</View>
    </View>
  );
}

/** Tiny magnifier drawn with views (no icon font needed). */
export function SearchIcon({ size = 20, color = '#fff' }: { size?: number; color?: string }) {
  const r = size * 0.62;
  return (
    <View style={{ width: size + 4, height: size + 4, alignItems: 'center', justifyContent: 'center' }}>
      <View
        style={{
          width: r,
          height: r,
          borderRadius: r / 2,
          borderWidth: 2,
          borderColor: color,
        }}
      />
      <View
        style={{
          position: 'absolute',
          bottom: 0,
          right: 0,
          width: size * 0.42,
          height: 2.5,
          backgroundColor: color,
          transform: [{ rotate: '45deg' }],
          borderRadius: 2,
        }}
      />
    </View>
  );
}

/** Colored avatar circle with the type emoji, like a WhatsApp contact photo. */
export function TypeAvatar({ style, size = 48 }: { style: TypeStyle; size?: number }) {
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        backgroundColor: style.color,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Text style={{ fontSize: size * 0.44 }}>{style.emoji}</Text>
    </View>
  );
}

/** WhatsApp-style date chip (Today / Yesterday / 12 Mar 2026). */
export function DateChip({ label }: { label: string }) {
  return (
    <View style={chipStyles.wrap}>
      <View style={chipStyles.chip}>
        <Text style={chipStyles.text}>{label}</Text>
      </View>
    </View>
  );
}

const chipStyles = StyleSheet.create({
  wrap: { alignItems: 'center', paddingVertical: 8 },
  chip: {
    backgroundColor: THEME.dateChipBg,
    borderColor: THEME.dateChipBorder,
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 5,
  },
  text: { color: THEME.dateChipText, fontSize: 12.5, fontWeight: '600' },
});

/** Green circular badge with a count (unread). */
export function CountBadge({ count }: { count: number }) {
  if (count <= 0) return null;
  return (
    <View style={badgeStyles.badge}>
      <Text style={badgeStyles.text}>{count > 99 ? '99+' : String(count)}</Text>
    </View>
  );
}

const badgeStyles = StyleSheet.create({
  badge: {
    minWidth: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: THEME.accent,
    paddingHorizontal: 6,
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: { color: '#0B3D2E', fontSize: 11.5, fontWeight: '700' },
});

/** Labeled settings input. */
export function Field({
  label,
  value,
  onChangeText,
  placeholder,
  autoCapitalize = 'none',
  keyboardType = 'default',
  secure = false,
  hint,
}: {
  label: string;
  value: string;
  onChangeText: (t: string) => void;
  placeholder?: string;
  autoCapitalize?: 'none' | 'sentences';
  keyboardType?: 'default' | 'email-address' | 'visible-password';
  secure?: boolean;
  hint?: string;
}) {
  return (
    <View style={fieldStyles.wrap}>
      <Text style={fieldStyles.label}>{label}</Text>
      <TextInput
        style={fieldStyles.input}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#9AA5AC"
        autoCapitalize={autoCapitalize}
        autoCorrect={false}
        keyboardType={keyboardType}
        secureTextEntry={secure}
      />
      {hint ? <Text style={fieldStyles.hint}>{hint}</Text> : null}
    </View>
  );
}

const fieldStyles = StyleSheet.create({
  wrap: { marginBottom: 16 },
  label: { color: THEME.textSecondary, fontSize: 12, fontWeight: '700', marginBottom: 6, textTransform: 'uppercase' },
  input: {
    backgroundColor: THEME.inputBg,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 15,
    color: THEME.textPrimary,
  },
  hint: { color: THEME.textSecondary, fontSize: 12, marginTop: 5, lineHeight: 16 },
});

const styles = StyleSheet.create({
  bar: {
    backgroundColor: THEME.header,
    paddingHorizontal: 12,
    paddingBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    elevation: 4,
  },
  backBtn: { paddingRight: 14 },
  backIcon: { color: '#fff', fontSize: 34, fontWeight: 'bold', lineHeight: 36, marginTop: -6 },
  barTitle: { color: '#fff', fontSize: 20, fontWeight: 'bold', flex: 1 },
  right: { flexDirection: 'row', alignItems: 'center', gap: 18 },
});
