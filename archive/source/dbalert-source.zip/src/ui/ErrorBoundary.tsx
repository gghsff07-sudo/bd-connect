/** Catches render errors so the app shows a message instead of force-closing. */
import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { THEME } from '../theme';

interface Props {
  children: React.ReactNode;
}
interface State {
  error: Error | null;
}

export default class ErrorBoundary extends React.Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error) {
    // keep in state; shown below
    this.setState({ error });
  }

  render() {
    if (this.state.error) {
      return (
        <View style={styles.root}>
          <View style={styles.header}>
            <Text style={styles.headerTitle}>DB Alert</Text>
          </View>
          <ScrollView contentContainerStyle={styles.body}>
            <Text style={styles.big}>Something went wrong</Text>
            <Text style={styles.text}>
              The app hit an unexpected error. Close DB Alert completely and open it again - your
              settings and history are saved.
            </Text>
            <Text style={styles.code}>{String(this.state.error?.message || this.state.error)}</Text>
          </ScrollView>
        </View>
      );
    }
    return this.props.children;
  }
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: THEME.listBg },
  header: { backgroundColor: THEME.header, padding: 18 },
  headerTitle: { color: '#fff', fontSize: 20, fontWeight: 'bold' },
  body: { padding: 20 },
  big: { fontSize: 20, fontWeight: 'bold', color: THEME.textPrimary, marginBottom: 10 },
  text: { fontSize: 15, color: THEME.textSecondary, lineHeight: 22, marginBottom: 14 },
  code: { fontFamily: 'monospace', fontSize: 12, color: THEME.danger },
});
