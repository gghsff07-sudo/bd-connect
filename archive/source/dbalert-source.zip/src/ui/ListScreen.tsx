/** History list screen: WhatsApp-style chat list of database updates. */
import React, { useMemo, useState } from 'react';
import {
  FlatList,
  RefreshControl,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { Item } from '../types';
import { classifyType } from '../lib/classify';
import { dayKey, dayLabel, timeLabel } from '../lib/normalize';
import { THEME } from '../theme';
import { AppBar, CountBadge, DateChip, SearchIcon, TypeAvatar } from './common';

export type Tab = 'updates' | 'done';

interface Props {
  items: Item[];
  tab: Tab;
  onTabChange: (t: Tab) => void;
  unreadIds: Set<string>;
  doneIds: Set<string>;
  configured: boolean;
  checking: boolean;
  onRefresh: () => void;
  onOpenItem: (id: string) => void;
  onOpenSettings: () => void;
}

export default function ListScreen(props: Props) {
  const { items, tab, unreadIds, doneIds, configured, checking } = props;
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return items.filter((it) => {
      const isDone = doneIds.has(it.id) || it.remoteDone;
      if (tab === 'done' ? !isDone : isDone) return false;
      if (!q) return true;
      return (
        it.title.toLowerCase().includes(q) ||
        it.body.toLowerCase().includes(q) ||
        it.type.toLowerCase().includes(q)
      );
    });
  }, [items, tab, doneIds, query]);

  const updatesCount = useMemo(
    () => items.filter((it) => !doneIds.has(it.id) && !it.remoteDone && unreadIds.has(it.id)).length,
    [items, doneIds, unreadIds]
  );

  const rows = useMemo(() => {
    // interleave date chips like WhatsApp message grouping
    const out: Array<{ kind: 'chip'; label: string; key: string } | { kind: 'item'; item: Item; key: string }> = [];
    let lastDay = '';
    for (const it of visible) {
      const ms = it.timeMs ?? it.sortMs;
      const dk = ms ? dayKey(ms) : 'unknown';
      if (dk !== lastDay) {
        out.push({ kind: 'chip', label: ms ? dayLabel(ms) : 'Earlier', key: `chip-${dk}-${it.id}` });
        lastDay = dk;
      }
      out.push({ kind: 'item', item: it, key: it.id });
    }
    return out;
  }, [visible]);

  return (
    <View style={styles.root}>
      <AppBar
        title="DB Alert"
        right={
          <>
            <TouchableOpacity
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              onPress={() => {
                setSearchOpen((v) => !v);
                if (searchOpen) setQuery('');
              }}
            >
              <SearchIcon />
            </TouchableOpacity>
            <TouchableOpacity hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }} onPress={props.onOpenSettings}>
              <Text style={styles.dots}>···</Text>
            </TouchableOpacity>
          </>
        }
      />

      {searchOpen ? (
        <View style={styles.searchWrap}>
          <TextInput
            style={styles.searchInput}
            value={query}
            onChangeText={setQuery}
            placeholder="Search updates"
            placeholderTextColor="#9AA5AC"
          />
        </View>
      ) : null}

      {/* WhatsApp-style top tabs */}
      <View style={styles.tabs}>
        <TabButton
          label="Updates"
          active={tab === 'updates'}
          badge={updatesCount}
          onPress={() => props.onTabChange('updates')}
        />
        <TabButton label="Done" active={tab === 'done'} onPress={() => props.onTabChange('done')} />
      </View>

      {!configured ? <Banner text="Database not connected yet - tap ··· > Settings to set it up." tone="warn" /> : null}

      <FlatList
        style={styles.list}
        data={rows}
        keyExtractor={(r) => r.key}
        refreshControl={<RefreshControl refreshing={checking} onRefresh={props.onRefresh} tintColor={THEME.header} />}
        ListEmptyComponent={<Empty tab={tab} configured={configured} />}
        renderItem={({ item }) =>
          item.kind === 'chip' ? (
            <DateChip label={item.label} />
          ) : (
            <Row item={item.item} unread={unreadIds.has(item.item.id)} done={tab === 'done'} onPress={() => props.onOpenItem(item.item.id)} />
          )
        }
        ItemSeparatorComponent={() => <View style={{ height: StyleSheet.hairlineWidth, backgroundColor: THEME.divider, marginLeft: 78 }} />}
      />
    </View>
  );
}

function TabButton({ label, active, badge, onPress }: { label: string; active: boolean; badge?: number; onPress: () => void }) {
  return (
    <TouchableOpacity style={styles.tabBtn} onPress={onPress} activeOpacity={0.7}>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <Text style={[styles.tabText, active && styles.tabTextActive]}>{label}</Text>
        {badge && badge > 0 ? <CountBadge count={badge} /> : null}
      </View>
      <View style={[styles.tabUnderline, active && { backgroundColor: THEME.accent }]} />
    </TouchableOpacity>
  );
}

function Row({ item, unread, done, onPress }: { item: Item; unread: boolean; done: boolean; onPress: () => void }) {
  const style = classifyType(item.type);
  const ms = item.timeMs ?? item.sortMs;
  return (
    <TouchableOpacity style={styles.row} onPress={onPress} activeOpacity={0.6}>
      <TypeAvatar style={style} />
      <View style={styles.rowMid}>
        <View style={styles.rowTop}>
          <Text style={[styles.rowTitle, unread && { fontWeight: '700' }]} numberOfLines={1}>
            {item.title}
          </Text>
          <Text style={styles.rowTime}>{ms ? timeLabel(ms) : ''}</Text>
        </View>
        <View style={styles.rowBottom}>
          {done ? <Text style={styles.ticksDone}>✓✓</Text> : null}
          <Text style={[styles.rowBody, unread && { color: THEME.textPrimary, fontWeight: '600' }]} numberOfLines={1}>
            {item.body || `${style.label} update`}
          </Text>
          {!done && unread ? <CountBadge count={1} /> : null}
        </View>
      </View>
    </TouchableOpacity>
  );
}

function Banner({ text, tone }: { text: string; tone: 'warn' | 'error' }) {
  return (
    <View style={[styles.banner, { backgroundColor: tone === 'warn' ? '#FFF7E0' : '#FDECEA' }]}>
      <Text style={[styles.bannerText, { color: tone === 'warn' ? '#8A6D00' : THEME.danger }]}>{text}</Text>
    </View>
  );
}

function Empty({ tab, configured }: { tab: Tab; configured: boolean }) {
  return (
    <View style={styles.emptyWrap}>
      <View style={styles.emptyCircle}>
        <Text style={{ fontSize: 34 }}>🔔</Text>
      </View>
      <Text style={styles.emptyTitle}>{tab === 'done' ? 'Nothing marked as done' : 'No updates yet'}</Text>
      <Text style={styles.emptyText}>
        {configured
          ? tab === 'done'
            ? 'Updates you mark as done will be listed here.'
            : 'DB Alert checks your database every 15 minutes.\nNew entries will appear here with a notification.'
          : 'Open ··· > Settings and connect your Firebase database to start monitoring it.'}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: THEME.listBg },
  dots: { color: '#fff', fontSize: 22, fontWeight: 'bold', letterSpacing: 2, lineHeight: 24 },
  searchWrap: { backgroundColor: THEME.header, paddingHorizontal: 12, paddingBottom: 10 },
  searchInput: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 7,
    color: '#fff',
    fontSize: 15,
  },
  tabs: { flexDirection: 'row', backgroundColor: THEME.listBg, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: THEME.divider },
  tabBtn: { flex: 1, paddingTop: 10, paddingHorizontal: 10, alignItems: 'center' },
  tabText: { color: THEME.textSecondary, fontSize: 15, fontWeight: '600' },
  tabTextActive: { color: THEME.header, fontWeight: '700' },
  tabUnderline: { height: 3, borderRadius: 2, width: 64, marginTop: 8 },
  list: { flex: 1 },
  banner: { paddingHorizontal: 16, paddingVertical: 8 },
  bannerText: { fontSize: 13, lineHeight: 18 },
  row: { flexDirection: 'row', paddingHorizontal: 16, paddingVertical: 11, alignItems: 'center', backgroundColor: THEME.listBg },
  rowMid: { flex: 1, marginLeft: 14 },
  rowTop: { flexDirection: 'row', alignItems: 'center' },
  rowTitle: { color: THEME.textPrimary, fontSize: 17, flex: 1, marginRight: 8, fontWeight: '400' },
  rowTime: { color: THEME.textSecondary, fontSize: 12 },
  rowBottom: { flexDirection: 'row', alignItems: 'center', marginTop: 3 },
  rowBody: { color: THEME.textSecondary, fontSize: 14, flex: 1, marginRight: 8 },
  ticksDone: { color: THEME.ticksBlue, fontSize: 13, fontWeight: '700', marginRight: 6 },
  emptyWrap: { alignItems: 'center', paddingHorizontal: 40, paddingTop: 80 },
  emptyCircle: {
    width: 84, height: 84, borderRadius: 42, backgroundColor: '#E7F3EF',
    alignItems: 'center', justifyContent: 'center', marginBottom: 18,
  },
  emptyTitle: { color: THEME.textPrimary, fontSize: 18, fontWeight: '700', marginBottom: 8 },
  emptyText: { color: THEME.textSecondary, fontSize: 14, lineHeight: 21, textAlign: 'center' },
});
