/** Deep-dive detail screen: full content, metadata, raw JSON, mark as done. */
import React, { useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { Item } from '../types';
import { classifyType } from '../lib/classify';
import { fullTimeLabel } from '../lib/normalize';
import { THEME } from '../theme';
import { AppBar, DateChip } from './common';

interface Props {
  item: Item;
  isDone: boolean;
  saving: boolean;
  dbWriteError: string | null;
  onBack: () => void;
  onToggleDone: (item: Item, next: boolean) => void;
}

export default function DetailScreen({ item, isDone, saving, dbWriteError, onBack, onToggleDone }: Props) {
  const style = classifyType(item.type);
  const [showRaw, setShowRaw] = useState(false);
  const ms = item.timeMs ?? item.sortMs;

  let rawJson = '';
  try {
    rawJson = JSON.stringify(item.raw, null, 2);
  } catch {
    rawJson = String(item.raw);
  }

  return (
    <View style={styles.root}>
      <AppBar title={item.title} onBack={onBack} />
      <ScrollView contentContainerStyle={styles.content}>
        {ms ? <DateChip label={fullTimeLabel(ms)} /> : null}

        {/* WhatsApp-style incoming bubble with the full message */}
        <View style={styles.bubble}>
          <View style={styles.typeRow}>
            <View style={[styles.typeChip, { backgroundColor: style.color }]}>
              <Text style={styles.typeChipText}>
                {style.emoji} {style.label}
              </Text>
            </View>
            {isDone ? (
              <View style={styles.doneChip}>
                <Text style={styles.doneChipText}>✓✓ Done</Text>
              </View>
            ) : null}
          </View>
          <Text style={styles.bubbleText}>{item.body && item.body.length > 0 ? item.body : '(no message content)'}</Text>
        </View>

        {/* metadata card */}
        <View style={styles.card}>
          <MetaRow label="Type" value={item.type} />
          <MetaRow label="Status" value={isDone ? 'Done' : 'Active'} valueColor={isDone ? THEME.ticksBlue : THEME.header} />
          <MetaRow label="Received" value={ms ? fullTimeLabel(ms) : 'Unknown'} />
          <MetaRow label="Source" value={item.kind === 'rtdb' ? 'Realtime Database' : 'Firestore'} />
          <View style={styles.metaRow}>
            <Text style={styles.metaLabel}>DOCUMENT ID</Text>
            <Text style={styles.metaMono} selectable>
              {item.id}
            </Text>
          </View>
        </View>

        {dbWriteError ? (
          <View style={styles.writeError}>
            <Text style={styles.writeErrorText}>Saved on this phone, but the database was not updated: {dbWriteError}</Text>
          </View>
        ) : null}

        {/* raw document (deep dive) */}
        <TouchableOpacity style={styles.card} onPress={() => setShowRaw((v) => !v)} activeOpacity={0.7}>
          <View style={styles.rawHeader}>
            <Text style={styles.rawTitle}>Raw document</Text>
            <Text style={styles.rawChevron}>{showRaw ? '▾' : '▸'}</Text>
          </View>
          {showRaw ? <Text style={styles.rawJson}>{rawJson}</Text> : <Text style={styles.rawHint}>Tap to inspect all fields exactly as stored</Text>}
        </TouchableOpacity>

        {/* actions */}
        <TouchableOpacity
          style={[styles.actionBtn, isDone ? styles.actionUndo : styles.actionDone, saving && { opacity: 0.6 }]}
          disabled={saving}
          onPress={() => onToggleDone(item, !isDone)}
        >
          {saving ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <Text style={styles.actionText}>{isDone ? 'Mark as active' : '✓  Mark as done'}</Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

function MetaRow({ label, value, valueColor }: { label: string; value: string; valueColor?: string }) {
  return (
    <View style={styles.metaRow}>
      <Text style={styles.metaLabel}>{label.toUpperCase()}</Text>
      <Text style={[styles.metaValue, valueColor ? { color: valueColor } : null]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: THEME.chatBg },
  content: { padding: 14, paddingBottom: 40 },
  bubble: {
    backgroundColor: THEME.bubbleIncoming,
    borderRadius: 14,
    borderTopLeftRadius: 2,
    padding: 14,
    marginBottom: 12,
    elevation: 1.5,
  },
  typeRow: { flexDirection: 'row', marginBottom: 10 },
  typeChip: { borderRadius: 12, paddingHorizontal: 10, paddingVertical: 4 },
  typeChipText: { color: '#fff', fontSize: 12.5, fontWeight: '700' },
  doneChip: {
    borderRadius: 12, paddingHorizontal: 10, paddingVertical: 4,
    backgroundColor: '#E8F6FD', marginLeft: 8,
  },
  doneChipText: { color: THEME.ticksBlue, fontSize: 12.5, fontWeight: '700' },
  bubbleText: { color: THEME.textPrimary, fontSize: 15.5, lineHeight: 23 },
  card: {
    backgroundColor: '#fff', borderRadius: 12, padding: 14, marginBottom: 12, elevation: 1.5,
  },
  metaRow: { marginBottom: 10 },
  metaLabel: { color: THEME.textSecondary, fontSize: 11.5, fontWeight: '700', marginBottom: 2 },
  metaValue: { color: THEME.textPrimary, fontSize: 15 },
  metaMono: { color: THEME.textPrimary, fontSize: 13, fontFamily: 'monospace' },
  writeError: {
    backgroundColor: '#FDECEA', borderRadius: 10, padding: 12, marginBottom: 12,
  },
  writeErrorText: { color: THEME.danger, fontSize: 13, lineHeight: 19 },
  rawHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  rawTitle: { color: THEME.textPrimary, fontSize: 15, fontWeight: '700' },
  rawChevron: { color: THEME.textSecondary, fontSize: 16 },
  rawHint: { color: THEME.textSecondary, fontSize: 13, marginTop: 4 },
  rawJson: {
    marginTop: 10, fontFamily: 'monospace', fontSize: 12, color: THEME.textPrimary,
    backgroundColor: THEME.inputBg, borderRadius: 8, padding: 10, lineHeight: 18,
  },
  actionBtn: { borderRadius: 12, paddingVertical: 14, alignItems: 'center', justifyContent: 'center', marginTop: 4 },
  actionDone: { backgroundColor: THEME.accent },
  actionUndo: { backgroundColor: THEME.header },
  actionText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
