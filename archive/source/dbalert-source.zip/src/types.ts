/** Shared types for DB Alert. */

export type DbKind = 'firestore' | 'rtdb';

/** User-editable configuration, stored in AsyncStorage. */
export interface AppConfig {
  kind: DbKind;
  projectId: string;
  apiKey: string;
  /** Firestore collection path or Realtime DB path. */
  path: string;
  /** Full Realtime DB URL, e.g. https://my-project-default-rtdb.firebaseio.com */
  dbUrl: string;
  /** Optional Firebase Auth sign-in (for databases with restricted rules). */
  authEmail: string;
  authPassword: string;
}

export const DEFAULT_CONFIG: AppConfig = {
  kind: 'firestore',
  projectId: '',
  apiKey: '',
  path: 'notifications',
  dbUrl: '',
  authEmail: '',
  authPassword: '',
};

/** One normalized item from the database, shown in history. */
export interface Item {
  id: string;
  title: string;
  body: string;
  /** Raw type value as found in the document (e.g. "payment"). */
  type: string;
  /** Best-effort timestamp in ms since epoch (null if unknown). */
  timeMs: number | null;
  /** A sortable timestamp (falls back to push-id / doc order). */
  sortMs: number;
  /** The document fields, decoded to plain JSON (for the "raw" view). */
  raw: Record<string, unknown>;
  /** True when the document itself is marked done in the database. */
  remoteDone: boolean;
  /** Field name used for writing status back, if detected. */
  statusField: string | null;
  /** Where this item came from. */
  kind: DbKind;
}

export interface CheckResultMeta {
  ok: boolean;
  at: number;
  error?: string;
  newCount?: number;
}
