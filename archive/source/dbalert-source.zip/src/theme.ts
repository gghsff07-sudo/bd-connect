/** WhatsApp-inspired visual theme. */
export const THEME = {
  // classic WhatsApp palette
  header: '#075E54', // teal green app bar
  headerDark: '#054D44', // status bar tint
  accent: '#25D366', // light green (badges, buttons)
  accentPressed: '#1DA85A',
  listBg: '#FFFFFF',
  chatBg: '#ECE5DD', // classic chat wallpaper
  bubbleIncoming: '#FFFFFF',
  dateChipBg: '#FFFFFF',
  dateChipBorder: '#E9EDEF',
  dateChipText: '#54656F',
  textPrimary: '#111B21',
  textSecondary: '#667781',
  divider: '#F0F0F0',
  ticksBlue: '#34B7F1',
  danger: '#E53935',
  warn: '#F59E0B',
  inputBg: '#F0F2F5',
  cardBorder: '#E9EDEF',
} as const;

export const fonts = {
  mono: 'monospace',
} as const;
