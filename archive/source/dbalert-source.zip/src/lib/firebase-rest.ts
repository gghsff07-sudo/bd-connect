/**
 * Firebase REST clients for Firestore and Realtime Database.
 * Pure fetch-based (no native Firebase SDK) - this is what keeps the app
 * crash-proof: there is no config-time native initialization that can throw.
 */
import { AppConfig, Item } from '../types';
import { fsValueToJs, normalizeDoc, RawDoc } from './normalize';

export class RestError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = 'RestError';
    this.status = status;
  }
}

// ---------- auth ----------

let authCache: { email: string; token: string; expiresAt: number } | null = null;

export function clearAuthCache(): void {
  authCache = null;
}

/** Signs in with email/password (optional) and returns an idToken, or null. */
export async function getAuthToken(cfg: AppConfig, force = false): Promise<string | null> {
  const email = (cfg.authEmail || '').trim();
  const password = cfg.authPassword || '';
  if (!email || !password) return null;
  if (!force && authCache && authCache.email === email && authCache.expiresAt > Date.now() + 60000) {
    return authCache.token;
  }
  const key = (cfg.apiKey || '').trim();
  if (!key) {
    throw new RestError('Sign-in email/password are set but the Web API key is missing.', 400);
  }
  const url = `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${encodeURIComponent(key)}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password, returnSecureToken: true }),
  });
  const json = (await res.json().catch(() => null)) as {
    idToken?: string;
    expiresIn?: string;
    error?: { message?: string };
  } | null;
  if (!res.ok || !json?.idToken) {
    const msg = json?.error?.message || `HTTP ${res.status}`;
    throw new RestError(`Sign-in failed: ${msg}`, res.status);
  }
  const expiresInSec = Number(json.expiresIn || '3600');
  authCache = {
    email,
    token: json.idToken,
    expiresAt: Date.now() + (Number.isFinite(expiresInSec) ? expiresInSec : 3600) * 1000,
  };
  return json.idToken;
}

// ---------- fetch helper ----------

async function fetchJson(url: string, init?: RequestInit): Promise<{ status: number; body: unknown }> {
  let res: Response;
  try {
    res = await fetch(url, init);
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : String(e);
    throw new RestError(`Network error: ${msg}. Check your internet connection.`, 0);
  }
  const body = await res.json().catch(() => null);
  return { status: res.status, body };
}

function apiErrorMessage(body: unknown, status: number, fallback: string): string {
  const b = body as { error?: { message?: string; status?: string } } | null;
  const raw = b?.error?.message || '';
  if (raw) {
    if (/permission/i.test(raw) || status === 403) {
      return `${fallback}: permission denied. Check your database rules, API key or sign-in details.`;
    }
    if (status === 404) {
      return `${fallback}: not found. Check the project id and the collection/path name.`;
    }
    if (status === 401) {
      return `${fallback}: unauthorized. Check your Web API key or sign-in details.`;
    }
    return `${fallback}: ${raw}`;
  }
  if (status === 404) return `${fallback}: not found. Check the project id and the collection/path name.`;
  if (status === 401 || status === 403) {
    return `${fallback}: permission denied. Check your database rules, API key or sign-in details.`;
  }
  return `${fallback}: HTTP ${status}`;
}

// ---------- Firestore ----------

export interface FsDocResponse {
  name?: string;
  fields?: Record<string, unknown>;
  createTime?: string;
  updateTime?: string;
}

function firestoreHeaders(token: string | null, apiKey: string): Record<string, string> {
  const h: Record<string, string> = {};
  const key = (apiKey || '').trim();
  if (key) h['x-goog-api-key'] = key;
  if (token) h.Authorization = `Bearer ${token}`;
  return h;
}

function encodeDocPath(path: string): string {
  return path
    .split('/')
    .filter((s) => s.length > 0)
    .map((s) => encodeURIComponent(s))
    .join('/');
}

async function firestoreListOnce(cfg: AppConfig, token: string | null): Promise<FsDocResponse[]> {
  const pid = cfg.projectId.trim();
  const path = encodeDocPath(cfg.path.trim() || 'notifications');
  const url =
    `https://firestore.googleapis.com/v1/projects/${encodeURIComponent(pid)}` +
    `/databases/(default)/documents/${path}?pageSize=250`;
  const { status, body } = await fetchJson(url, { headers: firestoreHeaders(token, cfg.apiKey) });
  if (status !== 200) {
    throw new RestError(apiErrorMessage(body, status, 'Firestore read failed'), status);
  }
  const docs = (body as { documents?: FsDocResponse[] } | null)?.documents;
  return Array.isArray(docs) ? docs : [];
}

/** Reads the collection and returns normalized items. Retries once with a fresh token on 401. */
export async function fetchFirestoreItems(cfg: AppConfig): Promise<Item[]> {
  let token = await getAuthToken(cfg).catch((e) => {
    throw e;
  });
  let docs: FsDocResponse[];
  try {
    docs = await firestoreListOnce(cfg, token);
  } catch (e) {
    if (e instanceof RestError && e.status === 401 && token) {
      token = await getAuthToken(cfg, true);
      docs = await firestoreListOnce(cfg, token);
    } else {
      throw e;
    }
  }
  const out: Item[] = [];
  for (const d of docs) {
    if (!d?.name) continue;
    const id = d.name.split('/').pop() || d.name;
    // decode Firestore typed values ({stringValue, integerValue, ...}) to plain JS
    const raw: Record<string, unknown> = {};
    const typed = d.fields;
    if (typed && typeof typed === 'object') {
      for (const k of Object.keys(typed)) {
        raw[k] = fsValueToJs((typed as Record<string, Parameters<typeof fsValueToJs>[0]>)[k]);
      }
    }
    out.push(normalizeDoc({ id, fields: raw, metaTimeIso: d.updateTime || d.createTime, kind: 'firestore' }));
  }
  return out;
}

// ---------- Realtime Database ----------

export function rtdbBaseUrl(cfg: AppConfig): string {
  const url = (cfg.dbUrl || '').trim();
  if (url) return url.replace(/\/+$/, '');
  const pid = cfg.projectId.trim();
  return `https://${pid}-default-rtdb.firebaseio.com`;
}

function encodeRtdbPath(path: string): string {
  return path
    .split('/')
    .filter((s) => s.length > 0)
    .map((s) => encodeURIComponent(s))
    .join('/');
}

async function rtdbListOnce(cfg: AppConfig, token: string | null): Promise<Record<string, unknown> | null> {
  const base = rtdbBaseUrl(cfg);
  const path = encodeRtdbPath(cfg.path.trim() || 'notifications');
  const authParam = token ? `?auth=${encodeURIComponent(token)}` : '';
  const { status, body } = await fetchJson(`${base}/${path}.json${authParam}`);
  if (status !== 200) {
    throw new RestError(apiErrorMessage(body, status, 'Realtime Database read failed'), status);
  }
  if (body == null) return null;
  if (typeof body !== 'object' || Array.isArray(body)) {
    throw new RestError('Realtime Database path did not return an object. Check the path.', 0);
  }
  return body as Record<string, unknown>;
}

export async function fetchRtdbItems(cfg: AppConfig): Promise<Item[]> {
  let token = await getAuthToken(cfg).catch((e) => {
    throw e;
  });
  let data: Record<string, unknown> | null;
  try {
    data = await rtdbListOnce(cfg, token);
  } catch (e) {
    if (e instanceof RestError && e.status === 401 && token) {
      token = await getAuthToken(cfg, true);
      data = await rtdbListOnce(cfg, token);
    } else {
      throw e;
    }
  }
  const out: Item[] = [];
  if (data) {
    for (const key of Object.keys(data)) {
      const val = data[key];
      const fields: Record<string, unknown> =
        val && typeof val === 'object' && !Array.isArray(val) ? (val as Record<string, unknown>) : { value: val };
      out.push(normalizeDoc({ id: key, fields, kind: 'rtdb' }));
    }
  }
  return out;
}

// ---------- public API ----------

export async function fetchItems(cfg: AppConfig): Promise<Item[]> {
  return cfg.kind === 'rtdb' ? fetchRtdbItems(cfg) : fetchFirestoreItems(cfg);
}

/** Cheap connectivity probe used by "Test connection" in settings. */
export async function testConnection(
  cfg: AppConfig
): Promise<{ ok: boolean; message: string; itemCount?: number }> {
  try {
    const token = await getAuthToken(cfg);
    if (cfg.kind === 'rtdb') {
      const data = await rtdbListOnce(cfg, token);
      const n = data ? Object.keys(data).length : 0;
      return { ok: true, message: `Connected. Found ${n} ${n === 1 ? 'entry' : 'entries'} in the database.`, itemCount: n };
    }
    const docs = await firestoreListOnce(cfg, token);
    return {
      ok: true,
      message: `Connected. Found ${docs.length} ${docs.length === 1 ? 'document' : 'documents'} in the collection.`,
      itemCount: docs.length,
    };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return { ok: false, message: msg };
  }
}

// ---------- mark as done (write-back) ----------

/** Attempts to mark a document done in the database. Throws with a readable message on failure. */
export async function markDoneRemote(cfg: AppConfig, item: Item, done: boolean): Promise<void> {
  const token = await getAuthToken(cfg);
  const nowIso = new Date().toISOString();
  const field = item.statusField || 'status';
  const isBoolField = /done|completed|isdone/i.test(field);

  if (cfg.kind === 'rtdb') {
    const base = rtdbBaseUrl(cfg);
    const path = encodeRtdbPath(cfg.path.trim());
    const authParam = token ? `?auth=${encodeURIComponent(token)}` : '';
    const payload: Record<string, unknown> = { doneAt: nowIso };
    payload[field] = isBoolField ? done : done ? 'done' : 'active';
    const { status, body } = await fetchJson(`${base}/${path}/${encodeURIComponent(item.id)}.json${authParam}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (status !== 200) {
      throw new RestError(apiErrorMessage(body, status, 'Database write failed'), status);
    }
    return;
  }

  const pid = cfg.projectId.trim();
  const path = encodeDocPath(cfg.path.trim());
  const fields: Record<string, unknown> = {
    doneAt: { timestampValue: nowIso },
    [field]: isBoolField ? { booleanValue: done } : { stringValue: done ? 'done' : 'active' },
  };
  const mask = `updateMask.fieldPaths=${encodeURIComponent(field)}&updateMask.fieldPaths=doneAt`;
  const url =
    `https://firestore.googleapis.com/v1/projects/${encodeURIComponent(pid)}` +
    `/databases/(default)/documents/${path}/${encodeURIComponent(item.id)}?${mask}`;
  const { status, body } = await fetchJson(url, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json', ...firestoreHeaders(token, cfg.apiKey) },
    body: JSON.stringify({ fields }),
  });
  if (status !== 200) {
    throw new RestError(apiErrorMessage(body, status, 'Database write failed'), status);
  }
}
