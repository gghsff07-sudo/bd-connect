/** AsyncStorage persistence layer. All keys are namespaced under "dbalert". */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppConfig, CheckResultMeta, DEFAULT_CONFIG, Item } from '../types';

const K = {
  config: '@dbalert/config',
  items: '@dbalert/items',
  seen: '@dbalert/seen',
  seenInit: '@dbalert/seen-init',
  done: '@dbalert/done',
  unread: '@dbalert/unread',
  lastCheck: '@dbalert/last-check',
  lastResult: '@dbalert/last-result',
} as const;

const MAX_ITEMS = 300;
const MAX_IDS = 3000;

async function getJson<T>(key: string, fallback: T): Promise<T> {
  try {
    const raw = await AsyncStorage.getItem(key);
    if (raw == null) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

async function setJson(key: string, value: unknown): Promise<void> {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(value));
  } catch {
    // storage full / unavailable: keep app alive, features degrade
  }
}

// ---------- config ----------

export async function loadConfig(): Promise<AppConfig> {
  const saved = await getJson<Partial<AppConfig> | null>(K.config, null);
  if (!saved || typeof saved !== 'object') return { ...DEFAULT_CONFIG };
  return { ...DEFAULT_CONFIG, ...saved };
}

export async function saveConfig(cfg: AppConfig): Promise<void> {
  await setJson(K.config, cfg);
}

export function isConfigUsable(cfg: AppConfig): boolean {
  if (cfg.kind === 'firestore') {
    return Boolean(cfg.projectId.trim()) && Boolean(cfg.path.trim());
  }
  const url = cfg.dbUrl.trim() || `https://${cfg.projectId.trim()}-default-rtdb.firebaseio.com`;
  return Boolean(url) && Boolean(cfg.path.trim());
}

// ---------- items cache ----------

export async function loadItems(): Promise<Item[]> {
  const items = await getJson<Item[]>(K.items, []);
  return Array.isArray(items) ? items : [];
}

export async function saveItems(items: Item[]): Promise<void> {
  await setJson(K.items, items.slice(0, MAX_ITEMS));
}

// ---------- id sets ----------

export async function loadSeenIds(): Promise<string[]> {
  const ids = await getJson<string[]>(K.seen, []);
  return Array.isArray(ids) ? ids : [];
}

export async function saveSeenIds(ids: string[]): Promise<void> {
  await setJson(K.seen, ids.slice(-MAX_IDS));
}

export async function loadSeenInit(): Promise<boolean> {
  return (await getJson<boolean>(K.seenInit, false)) === true;
}

export async function saveSeenInit(): Promise<void> {
  await setJson(K.seenInit, true);
}

export async function loadDoneIds(): Promise<string[]> {
  const ids = await getJson<string[]>(K.done, []);
  return Array.isArray(ids) ? ids : [];
}

export async function saveDoneIds(ids: string[]): Promise<void> {
  await setJson(K.done, ids.slice(-MAX_IDS));
}

export async function loadUnreadIds(): Promise<string[]> {
  const ids = await getJson<string[]>(K.unread, []);
  return Array.isArray(ids) ? ids : [];
}

export async function saveUnreadIds(ids: string[]): Promise<void> {
  await setJson(K.unread, ids.slice(-MAX_IDS));
}

// ---------- check bookkeeping ----------

export async function loadLastCheck(): Promise<number> {
  return await getJson<number>(K.lastCheck, 0);
}

export async function saveLastCheck(t: number): Promise<void> {
  await setJson(K.lastCheck, t);
}

export async function loadLastResult(): Promise<CheckResultMeta | null> {
  return await getJson<CheckResultMeta | null>(K.lastResult, null);
}

export async function saveLastResult(r: CheckResultMeta): Promise<void> {
  await setJson(K.lastResult, r);
}

// ---------- reset ----------

export async function resetAllData(): Promise<void> {
  try {
    await AsyncStorage.multiRemove(Object.values(K));
  } catch {
    // ignore
  }
}
