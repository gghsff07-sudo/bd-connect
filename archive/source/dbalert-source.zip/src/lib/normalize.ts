/**
 * Normalizes documents from Firestore / Realtime DB into `Item` objects.
 * Pure logic only (no react-native imports) so it can be unit-tested in Node.
 */
import { DbKind, Item } from '../types';

// ---------- field name candidates ----------

const TITLE_KEYS = ['title', 'heading', 'subject', 'name', 'label', 'summary', 'notificationTitle', 'header', 'topic'];
const BODY_KEYS = ['body', 'message', 'text', 'content', 'description', 'detail', 'msg', 'notificationBody', 'note', 'value'];
const TYPE_KEYS = ['type', 'category', 'kind', 'eventType', 'level', 'severity', 'priority', 'tag', 'notificationType'];
const TIME_KEYS = [
  'createdAt', 'created_at', 'created', 'timestamp', 'time', 'date', 'datetime', 'ts',
  'sentAt', 'sent_at', 'eventTime', 'occurredAt', 'updatedAt', 'updated_at',
];
const DONE_KEYS = ['status', 'state', 'done', 'isDone', 'completed', 'completedAt', 'doneAt'];

// ---------- Firestore typed-value decoding ----------

interface FsValue {
  stringValue?: string;
  integerValue?: string;
  doubleValue?: number;
  booleanValue?: boolean;
  timestampValue?: string;
  nullValue?: string | null;
  mapValue?: { fields?: Record<string, FsValue> };
  arrayValue?: { values?: FsValue[] };
  referenceValue?: string;
  geoPointValue?: { latitude: number; longitude: number };
  bytesValue?: string;
}

export function fsValueToJs(v: FsValue | undefined): unknown {
  if (v == null) return null;
  if (v.stringValue !== undefined) return v.stringValue;
  if (v.integerValue !== undefined) {
    const n = Number(v.integerValue);
    return Number.isFinite(n) ? n : v.integerValue;
  }
  if (v.doubleValue !== undefined) return v.doubleValue;
  if (v.booleanValue !== undefined) return v.booleanValue;
  if (v.timestampValue !== undefined) return v.timestampValue;
  if (v.mapValue !== undefined) {
    const out: Record<string, unknown> = {};
    const fields = v.mapValue?.fields ?? {};
    for (const k of Object.keys(fields)) out[k] = fsValueToJs(fields[k]);
    return out;
  }
  if (v.arrayValue !== undefined) {
    return (v.arrayValue?.values ?? []).map((x) => fsValueToJs(x));
  }
  if (v.referenceValue !== undefined) return v.referenceValue;
  if (v.geoPointValue !== undefined) return v.geoPointValue;
  if (v.bytesValue !== undefined) return v.bytesValue;
  return null;
}

// ---------- time helpers ----------

/** Converts many common shapes (ms, seconds, ISO string, {_seconds}) to epoch ms. */
export function toMs(v: unknown): number | null {
  if (typeof v === 'number' && Number.isFinite(v)) {
    if (v > 1e12) return v; // already ms
    if (v > 1e8) return v * 1000; // seconds
    return null;
  }
  if (typeof v === 'string') {
    const p = Date.parse(v);
    return Number.isNaN(p) ? null : p;
  }
  if (v && typeof v === 'object') {
    const o = v as { _seconds?: unknown; seconds?: unknown };
    const sec =
      typeof o._seconds === 'number' ? o._seconds : typeof o.seconds === 'number' ? o.seconds : null;
    if (sec !== null) return sec * 1000;
  }
  return null;
}

const PUSH_CHARS = '-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz';

/** Decodes the creation time (ms) encoded in the first 8 chars of a Firebase push id. */
export function pushIdToMs(id: string): number | null {
  if (!id || id.length < 8) return null;
  let ts = 0;
  for (let i = 0; i < 8; i++) {
    const idx = PUSH_CHARS.indexOf(id[i]);
    if (idx < 0) return null;
    ts = ts * 64 + idx;
  }
  return ts;
}

function extractTime(fields: Record<string, unknown>, metaIso?: string): number | null {
  for (const k of TIME_KEYS) {
    const t = toMs(fields[k]);
    if (t !== null) return t;
  }
  // second pass: any key mentioning time/date
  for (const k of Object.keys(fields)) {
    if (/time|date/i.test(k)) {
      const t = toMs(fields[k]);
      if (t !== null) return t;
    }
  }
  if (metaIso) {
    const t = Date.parse(metaIso);
    if (!Number.isNaN(t)) return t;
  }
  return null;
}

// ---------- string helpers ----------

function asText(v: unknown): string | null {
  if (typeof v === 'string' && v.trim().length > 0) return v.trim();
  if (typeof v === 'number' && Number.isFinite(v)) return String(v);
  if (typeof v === 'boolean') return String(v);
  return null;
}

function pickField(fields: Record<string, unknown>, keys: string[]): string | null {
  for (const k of keys) {
    const v = asText(fields[k]);
    if (v !== null) return v;
  }
  return null;
}

// ---------- done detection ----------

export function detectRemoteDone(
  fields: Record<string, unknown>
): { done: boolean; statusField: string | null } {
  for (const k of DONE_KEYS) {
    if (!(k in fields)) continue;
    const v = fields[k];
    if (typeof v === 'boolean') return { done: v, statusField: k };
    if (typeof v === 'string') {
      const s = v.trim().toLowerCase();
      if (['done', 'completed', 'complete', 'closed', 'resolved', 'read', 'true', 'yes', '1'].includes(s)) {
        return { done: true, statusField: k };
      }
      if (['pending', 'active', 'new', 'open', 'todo', 'false', 'no', '0'].includes(s)) {
        return { done: false, statusField: k };
      }
    }
  }
  return { done: false, statusField: null };
}

// ---------- normalization ----------

export interface RawDoc {
  id: string;
  fields: Record<string, unknown>;
  metaTimeIso?: string;
  kind: DbKind;
}

export function normalizeDoc(doc: RawDoc): Item {
  const fields = doc.fields && typeof doc.fields === 'object' ? (doc.fields as Record<string, unknown>) : {};
  const title = pickField(fields, TITLE_KEYS) ?? 'New update';
  const body = pickField(fields, BODY_KEYS) ?? '';
  const type = pickField(fields, TYPE_KEYS) ?? 'general';
  const timeMs = extractTime(fields, doc.metaTimeIso);
  const { done, statusField } = detectRemoteDone(fields);

  let sortMs = timeMs ?? 0;
  if (!sortMs) {
    const pid = pushIdToMs(doc.id);
    if (pid !== null) sortMs = pid;
  }

  return {
    id: doc.id,
    title,
    body,
    type,
    timeMs,
    sortMs,
    raw: fields,
    remoteDone: done,
    statusField,
    kind: doc.kind,
  };
}

// ---------- merge / diff (used by the poller) ----------

/** Merges freshly fetched items over cached ones, keeps newest first, caps length. */
export function mergeItems(prev: Item[], fresh: Item[], cap = 300): Item[] {
  const byId = new Map<string, Item>();
  for (const it of prev) byId.set(it.id, it);
  for (const it of fresh) byId.set(it.id, it);
  const merged = Array.from(byId.values());
  merged.sort((a, b) => b.sortMs - a.sortMs);
  return merged.slice(0, cap);
}

/** Returns items that have never been seen before (ordered oldest first). */
export function diffNew(items: Item[], seenIds: Set<string>): Item[] {
  return items.filter((it) => !seenIds.has(it.id)).sort((a, b) => a.sortMs - b.sortMs);
}

// ---------- display helpers ----------

const DAY = 86400000;

function startOfDay(ms: number): number {
  const d = new Date(ms);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

export function dayKey(ms: number): string {
  const d = new Date(ms);
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

export function dayLabel(ms: number): string {
  const today = startOfDay(Date.now());
  const day = startOfDay(ms);
  if (day === today) return 'Today';
  if (day === today - DAY) return 'Yesterday';
  const d = new Date(ms);
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function timeLabel(ms: number): string {
  const d = new Date(ms);
  const h = d.getHours();
  const m = d.getMinutes();
  const ampm = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${h12}:${String(m).padStart(2, '0')} ${ampm}`;
}

export function fullTimeLabel(ms: number): string {
  if (!ms) return 'Unknown time';
  return `${dayLabel(ms)}, ${timeLabel(ms)}`;
}
