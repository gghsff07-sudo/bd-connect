/**
 * Classifies a raw "type" value into a notification style.
 * This is what makes notifications "proper ... based on type":
 * each class gets its own Android notification channel with its own
 * importance, vibration pattern and color, plus a distinct emoji.
 */
import { AndroidImportance } from 'expo-notifications';
import { NotificationChannelInput } from 'expo-notifications';

export interface TypeStyle {
  /** stable key, used for the channel id */
  key: string;
  label: string;
  emoji: string;
  color: string;
  importance: AndroidImportance;
  vibration: number[];
  bypassDnd: boolean;
  channelName: string;
}

interface Classifier extends TypeStyle {
  keywords: string[];
}

const CLASSIFIERS: Classifier[] = [
  {
    key: 'critical',
    label: 'Critical',
    emoji: '🚨',
    color: '#E53935',
    importance: AndroidImportance.MAX,
    vibration: [0, 700, 300, 700, 300, 700],
    bypassDnd: true,
    channelName: 'Critical alerts',
    keywords: [
      'critical', 'urgent', 'emergency', 'severe', 'fail', 'failed', 'failure',
      'error', 'down', 'outage', 'alarm', 'fraud', 'suspicious', 'blocked',
      'overdue', 'cancel',
    ],
  },
  {
    key: 'warning',
    label: 'Warning',
    emoji: '⚠️',
    color: '#FF8C00',
    importance: AndroidImportance.HIGH,
    vibration: [0, 400, 200, 400, 200, 400],
    bypassDnd: false,
    channelName: 'Warnings',
    keywords: [
      'warning', 'caution', 'alert', 'risk', 'attention', 'expiring', 'expire',
      'expired', 'reminder', 'low', 'limit', 'retry', 'pending',
    ],
  },
  {
    key: 'payment',
    label: 'Payment',
    emoji: '💰',
    color: '#25D366',
    importance: AndroidImportance.HIGH,
    vibration: [0, 300, 150, 300],
    bypassDnd: false,
    channelName: 'Payment updates',
    keywords: [
      'payment', 'paid', 'money', 'transaction', 'invoice', 'bill', 'refund',
      'cash', 'salary', 'credit', 'debit', 'withdraw', 'fee', 'charge',
      'subscription', 'topup', 'top-up', 'balance',
    ],
  },
  {
    key: 'order',
    label: 'Order',
    emoji: '📦',
    color: '#128C7E',
    importance: AndroidImportance.DEFAULT,
    vibration: [0, 250],
    bypassDnd: false,
    channelName: 'Order updates',
    keywords: [
      'order', 'booking', 'reservation', 'delivery', 'shipping', 'dispatch',
      'package', 'shipment', 'pickup', 'appointment',
    ],
  },
  {
    key: 'info',
    label: 'Info',
    emoji: 'ℹ️',
    color: '#075E54',
    importance: AndroidImportance.DEFAULT,
    vibration: [0, 250],
    bypassDnd: false,
    channelName: 'Info updates',
    keywords: [
      'info', 'information', 'notice', 'update', 'news', 'general', 'message',
      'system', 'success', 'complete', 'completed', 'sync', 'report',
    ],
  },
];

const DEFAULT_STYLE: TypeStyle = {
  key: 'general',
  label: 'General',
  emoji: '🔔',
  color: '#128C7E',
  importance: AndroidImportance.DEFAULT,
  vibration: [0, 250],
  bypassDnd: false,
  channelName: 'General updates',
};

export const TEST_STYLE: TypeStyle = {
  key: 'test',
  label: 'Test',
  emoji: '🔔',
  color: '#075E54',
  importance: AndroidImportance.DEFAULT,
  vibration: [0, 250],
  bypassDnd: false,
  channelName: 'Test notifications',
};

const cache = new Map<string, TypeStyle>();

/** Returns the notification style for a raw type string (case-insensitive). */
export function classifyType(rawType: string | null | undefined): TypeStyle {
  const t = (rawType || '').toString().trim().toLowerCase();
  if (!t) return DEFAULT_STYLE;
  const hit = cache.get(t);
  if (hit) return hit;
  let style: TypeStyle = DEFAULT_STYLE;
  for (const c of CLASSIFIERS) {
    if (c.keywords.some((kw) => t.includes(kw))) {
      const { keywords: _kw, ...rest } = c;
      style = rest;
      break;
    }
  }
  cache.set(t, style);
  return style;
}

/** Channel id for a style. */
export function channelIdFor(style: TypeStyle): string {
  return `dbalert-${style.key}`;
}

/** Channel definition for a style (expo-notifications input). */
export function channelInputFor(style: TypeStyle): NotificationChannelInput & { id: string } {
  return {
    id: channelIdFor(style),
    name: style.channelName,
    importance: style.importance,
    vibrationPattern: style.vibration,
    lightColor: style.color,
    sound: 'default',
    bypassDnd: style.bypassDnd,
    lockscreenVisibility: 1, // AndroidNotificationVisibility.PUBLIC
    enableVibrate: true,
    showBadge: true,
  };
}
