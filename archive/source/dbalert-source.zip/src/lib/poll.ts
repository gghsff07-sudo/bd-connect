/**
 * The shared 15-minute poller.
 * Runs in the foreground (interval) and in the background (expo-background-task,
 * WorkManager on Android with a 15 minute minimum interval).
 */
import * as BackgroundTask from 'expo-background-task';
import * as TaskManager from 'expo-task-manager';
import { AppConfig, Item } from '../types';
import { fetchItems } from './firebase-rest';
import { postItemNotifications, updateBadge } from './notify';
import { diffNew, mergeItems } from './normalize';
import {
  isConfigUsable,
  loadConfig,
  loadDoneIds,
  loadItems,
  loadLastResult,
  loadSeenIds,
  loadSeenInit,
  loadUnreadIds,
  saveItems,
  saveLastCheck,
  saveLastResult,
  saveSeenIds,
  saveSeenInit,
  saveUnreadIds,
  saveDoneIds,
} from './storage';

export const BACKGROUND_POLL_TASK = 'dbalert-poll';

export interface CheckOutcome {
  ok: boolean;
  newCount: number;
  error?: string;
}

let inFlight = false;

/**
 * Performs one database check: fetch -> normalize -> diff -> notify -> cache.
 * Never throws. Safe to call from any context (UI, background task, refresh).
 */
export async function performCheck(): Promise<CheckOutcome> {
  if (inFlight) {
    return { ok: true, newCount: 0 };
  }
  inFlight = true;
  try {
    const cfg: AppConfig = await loadConfig();
    if (!isConfigUsable(cfg)) {
      await saveLastResult({ ok: false, at: Date.now(), error: 'Database not set up yet.' });
      return { ok: false, newCount: 0, error: 'Database not set up yet.' };
    }

    const fresh = await fetchItems(cfg); // throws RestError with readable message
    const prev = await loadItems();
    const merged = mergeItems(prev, fresh);

    const seen = new Set(await loadSeenIds());
    const initialized = await loadSeenInit();

    let newItems: Item[] = [];
    if (!initialized) {
      // First run after setup: baseline everything as seen, do NOT spam notifications
      for (const it of fresh) seen.add(it.id);
      await saveSeenInit();
    } else {
      newItems = diffNew(fresh, seen);
      for (const it of newItems) seen.add(it.id);
    }

    await saveItems(merged);
    await saveSeenIds(Array.from(seen));

    if (newItems.length > 0) {
      const unread = new Set(await loadUnreadIds());
      for (const it of newItems) unread.add(it.id);
      await saveUnreadIds(Array.from(unread));
      await postItemNotifications(newItems);
    }

    const unreadCount = (await loadUnreadIds()).length;
    await updateBadge(unreadCount);

    await saveLastCheck(Date.now());
    const result = { ok: true, at: Date.now(), newCount: newItems.length };
    await saveLastResult(result);
    return { ok: true, newCount: newItems.length };
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : String(e);
    await saveLastResult({ ok: false, at: Date.now(), error: message });
    return { ok: false, newCount: 0, error: message };
  } finally {
    inFlight = false;
  }
}

// ---------------------------------------------------------------------------
// Background task definition. MUST live at module scope and be imported from
// the app entry so it is registered when the headless task wakes the app.
// ---------------------------------------------------------------------------

TaskManager.defineTask(BACKGROUND_POLL_TASK, async () => {
  try {
    const outcome = await performCheck();
    return outcome.ok
      ? BackgroundTask.BackgroundTaskResult.Success
      : BackgroundTask.BackgroundTaskResult.Failed;
  } catch {
    return BackgroundTask.BackgroundTaskResult.Failed;
  }
});

/** Registers the recurring 15-minute background poll (idempotent). */
export async function ensureBackgroundPollRegistered(): Promise<boolean> {
  try {
    const status = await BackgroundTask.getStatusAsync();
    if (status !== BackgroundTask.BackgroundTaskStatus.Available) {
      return false;
    }
    const already = await TaskManager.isTaskRegisteredAsync(BACKGROUND_POLL_TASK);
    if (!already) {
      await BackgroundTask.registerTaskAsync(BACKGROUND_POLL_TASK, {
        minimumInterval: 15, // minutes (Android WorkManager minimum)
      });
    }
    return true;
  } catch {
    return false;
  }
}

/** Reads everything the UI needs after a check (also used on app foreground). */
export async function loadUiState() {
  const [items, unread, done, lastResult, cfg, seen] = await Promise.all([
    loadItems(),
    loadUnreadIds(),
    loadDoneIds(),
    loadLastResult(),
    loadConfig(),
    loadSeenIds(),
  ]);
  return {
    items,
    unreadIds: new Set(unread),
    doneIds: new Set(done),
    lastResult,
    lastCheck: lastResult?.at ?? 0,
    config: cfg,
    seenCount: seen.length,
  };
}

// re-export for App
export { loadDoneIds, saveDoneIds };

export async function diagnose(): Promise<{
  taskRegistered: boolean;
  items: number;
  unread: number;
  done: number;
  seen: number;
  lastResult: Awaited<ReturnType<typeof loadLastResult>>;
}> {
  const [reg, items, unread, done, seen, lastResult] = await Promise.all([
    TaskManager.isTaskRegisteredAsync(BACKGROUND_POLL_TASK).catch(() => false),
    loadItems(),
    loadUnreadIds(),
    loadDoneIds(),
    loadSeenIds(),
    loadLastResult(),
  ]);
  return {
    taskRegistered: reg,
    items: items.length,
    unread: unread.length,
    done: done.length,
    seen: seen.length,
    lastResult,
  };
}
