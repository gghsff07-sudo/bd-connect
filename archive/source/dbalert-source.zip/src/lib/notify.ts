/** Local notifications: channels per type, permission handling, badge. */
import * as Notifications from 'expo-notifications';
import { Item } from '../types';
import { channelInputFor, classifyType } from './classify';

// Show notifications even while the app is in the foreground.
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

export async function ensureNotificationPermission(): Promise<boolean> {
  try {
    const cur = await Notifications.getPermissionsAsync();
    if (cur.granted) return true;
    if (cur.canAskAgain === false) return false;
    const req = await Notifications.requestPermissionsAsync();
    return req.granted === true;
  } catch {
    return false;
  }
}

async function ensureChannel(styleId: string, style: ReturnType<typeof classifyType>): Promise<void> {
  try {
    await Notifications.setNotificationChannelAsync(styleId, channelInputFor(style));
  } catch {
    // channel creation failed (e.g. unknown importance) - notification still posts to default channel
  }
}

/** Posts one notification for a new item, styled by its type. */
export async function postItemNotification(item: Item): Promise<void> {
  const style = classifyType(item.type);
  const channelId = `dbalert-${style.key}`;
  await ensureChannel(channelId, style);
  const body = item.body && item.body.length > 0 ? item.body : `New ${style.label.toLowerCase()} update in your database.`;
  await Notifications.scheduleNotificationAsync({
    content: {
      title: `${style.emoji} ${item.title}`.slice(0, 180),
      body: body.slice(0, 250),
      data: { itemId: item.id },
      sound: 'default',
      color: style.color,
      vibrate: style.vibration,
      autoDismiss: true,
    },
    trigger: null,
  });
}

const MAX_PER_CHECK = 5;

/** Posts up to 5 notifications plus a summary, returns how many were posted. */
export async function postItemNotifications(newItems: Item[]): Promise<number> {
  const permitted = await ensureNotificationPermission();
  if (!permitted || newItems.length === 0) return 0;
  let posted = 0;
  try {
    const slice = newItems.slice(0, MAX_PER_CHECK);
    for (const item of slice) {
      try {
        await postItemNotification(item);
        posted++;
      } catch {
        // keep posting the rest
      }
    }
    if (newItems.length > MAX_PER_CHECK) {
      try {
        await Notifications.scheduleNotificationAsync({
          content: {
            title: '🔔 More new updates',
            body: `...and ${newItems.length - MAX_PER_CHECK} more waiting in DB Alert.`,
            sound: 'default',
          },
          trigger: null,
        });
      } catch {
        // ignore
      }
    }
  } catch {
    // never let notification posting break the poll
  }
  return posted;
}

/** Posts a sample notification from the settings screen. */
export async function postTestNotification(): Promise<void> {
  const { TEST_STYLE } = await import('./classify');
  await ensureChannel(`dbalert-${TEST_STYLE.key}`, TEST_STYLE);
  await Notifications.scheduleNotificationAsync({
    content: {
      title: '🔔 Test notification',
      body: 'If you can read this, notifications from DB Alert will reach you.',
      sound: 'default',
      color: TEST_STYLE.color,
    },
    trigger: null,
  });
}

export async function updateBadge(unreadCount: number): Promise<void> {
  try {
    await Notifications.setBadgeCountAsync(Math.max(0, Math.min(unreadCount, 999)));
  } catch {
    // ignore
  }
}
