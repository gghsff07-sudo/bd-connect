#!/usr/bin/env python3
"""Insert Huawei Maven mirror before mavenCentral() in the RN/expo composite
gradle builds inside node_modules (they are wiped on npm ci). Kotlin DSL only."""
import glob
import re

ROOT = '/home/z/my-project/app'
MIRROR = 'maven("https://repo.huaweicloud.com/repository/maven/")'

files = []
files += glob.glob(f'{ROOT}/node_modules/@react-native/gradle-plugin/**/*.gradle.kts', recursive=True)
files += glob.glob(f'{ROOT}/node_modules/expo-modules-autolinking/android/expo-gradle-plugin/**/*.gradle.kts', recursive=True)

patched = []
for f in files:
    s = open(f).read()
    if 'huaweicloud' in s:
        continue
    new = re.sub(r'(\n(\s*))mavenCentral\(\)', r'\1\2' + MIRROR + r'\1\2mavenCentral()', s)
    new = new.replace(
        'repositories { mavenCentral() }',
        'repositories {\n  ' + MIRROR + '\n  mavenCentral()\n}',
    )
    if new != s:
        open(f, 'w').write(new)
        patched.append(f)

print('patched', len(patched), 'files:')
for f in patched:
    print(' -', f)
