#!/usr/bin/env node
/* Logic tests for DB Alert pure modules (run in Node with mocked fetch). */
const Module = require('module');
const path = require('path');

// stub expo-notifications (native module) with the enum values we use
const origLoad = Module._load;
Module._load = function (request, parent, isMain) {
  if (request === 'expo-notifications') {
    return {
      AndroidImportance: { UNKNOWN: 0, UNSPECIFIED: 1, NONE: 2, MIN: 3, LOW: 4, DEFAULT: 5, HIGH: 6, MAX: 7 },
    };
  }
  return origLoad.apply(this, arguments);
};

const { classifyType, channelIdFor } = require('/tmp/tsbuild/lib/classify.js');
const N = require('/tmp/tsbuild/lib/normalize.js');
const R = require('/tmp/tsbuild/lib/firebase-rest.js');

let pass = 0, fail = 0;
function ok(cond, name) {
  if (cond) { pass++; }
  else { fail++; console.error('FAIL:', name); }
}
function eq(a, b, name) {
  const ja = JSON.stringify(a), jb = JSON.stringify(b);
  ok(ja === jb, `${name} (${ja} !== ${jb})`);
}

// ---------- classify ----------
ok(classifyType('payment').key === 'payment', 'classify payment');
ok(classifyType('PAYMENT_RECEIVED').key === 'payment', 'classify payment case-insensitive');
ok(classifyType('critical battery').key === 'critical', 'classify critical');
ok(classifyType('System failure').key === 'critical', 'classify failure as critical');
ok(classifyType('expiring soon').key === 'warning', 'classify expiring as warning');
ok(classifyType('new order').key === 'order', 'classify order');
ok(classifyType('general news').key === 'info', 'classify news as info');
ok(classifyType('').key === 'general', 'classify empty as general');
ok(classifyType(null).key === 'general', 'classify null as general');
ok(classifyType('somethingrandom').key === 'general', 'classify unknown as general');
ok(classifyType('critical').importance === 7, 'critical uses MAX importance');
ok(classifyType('payment').vibration.length === 4, 'payment vibration pattern');
ok(channelIdFor(classifyType('warning')) === 'dbalert-warning', 'channel id for warning');

// ---------- fsValueToJs ----------
eq(N.fsValueToJs({ stringValue: 'hello' }), 'hello', 'fs string');
eq(N.fsValueToJs({ integerValue: '42' }), 42, 'fs integer');
eq(N.fsValueToJs({ doubleValue: 1.5 }), 1.5, 'fs double');
eq(N.fsValueToJs({ booleanValue: true }), true, 'fs bool');
eq(N.fsValueToJs({ mapValue: { fields: { a: { stringValue: 'x' }, b: { integerValue: '2' } } } }), { a: 'x', b: 2 }, 'fs map');
eq(N.fsValueToJs({ arrayValue: { values: [{ stringValue: 'a' }, { stringValue: 'b' }] } }), ['a', 'b'], 'fs array');

// ---------- toMs ----------
eq(N.toMs(1731300000000), 1731300000000, 'toMs ms');
eq(N.toMs(1731300000), 1731300000000, 'toMs seconds');
eq(N.toMs('2026-03-12T10:00:00Z'), Date.parse('2026-03-12T10:00:00Z'), 'toMs iso');
eq(N.toMs({ _seconds: 1731300000 }), 1731300000000, 'toMs _seconds');
eq(N.toMs('not a date'), null, 'toMs invalid');
eq(N.toMs(42), null, 'toMs tiny number');

// ---------- pushIdToMs roundtrip ----------
const PUSH = '-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz';
function encodePush(ms) {
  let s = '';
  for (let i = 7; i >= 0; i--) { s += PUSH[Math.floor(ms / Math.pow(64, i)) % 64]; }
  return s;
}
const ms1 = 1770000000000;
const pid = encodePush(ms1) + 'abcdefghijk';
eq(N.pushIdToMs(pid), ms1, 'pushIdToMs roundtrip');
eq(N.pushIdToMs('short'), null, 'pushIdToMs short');

// ---------- normalizeDoc ----------
const fsDoc = {
  id: 'docA',
  fields: { title: 'Payment received', message: 'You received $50', type: 'payment', createdAt: '2026-03-10T08:30:00Z' },
  metaTimeIso: '2026-03-10T08:31:00Z',
  kind: 'firestore',
};
const itA = N.normalizeDoc(fsDoc);
eq(itA.title, 'Payment received', 'normalize title');
eq(itA.body, 'You received $50', 'normalize body');
eq(itA.type, 'payment', 'normalize type');
eq(itA.timeMs, Date.parse('2026-03-10T08:30:00Z'), 'normalize time from createdAt');
ok(itA.remoteDone === false, 'normalize not done');

// fallback field names
const itB = N.normalizeDoc({ id: 'docB', fields: { subject: 'Heading here', description: 'Desc', category: 'warning', ts: 1770000000000 }, kind: 'firestore' });
eq(itB.title, 'Heading here', 'fallback title subject');
eq(itB.body, 'Desc', 'fallback body description');
eq(itB.type, 'warning', 'fallback type category');
eq(itB.timeMs, 1770000000000, 'fallback time ts');

// done detection
ok(N.normalizeDoc({ id: 'd', fields: { status: 'done' }, kind: 'firestore' }).remoteDone === true, 'status done detected');
ok(N.normalizeDoc({ id: 'd', fields: { done: true }, kind: 'firestore' }).remoteDone === true, 'done bool detected');
ok(N.normalizeDoc({ id: 'd', fields: { status: 'pending' }, kind: 'firestore' }).remoteDone === false, 'status pending active');
ok(N.normalizeDoc({ id: 'd', fields: { isDone: false }, kind: 'firestore' }).statusField === 'isDone', 'statusField isDone');

// no time -> push id sort fallback
const itC = N.normalizeDoc({ id: pid, fields: { title: 'T' }, kind: 'rtdb' });
eq(itC.timeMs, null, 'rtdb no time field -> null timeMs');
eq(itC.sortMs, ms1, 'rtdb sort from push id');

// ---------- merge / diff ----------
const prev = [
  { id: 'a', sortMs: 100, title: 'old a' },
  { id: 'b', sortMs: 200, title: 'old b' },
];
const fresh = [
  { id: 'a', sortMs: 100, title: 'new a' }, // updated
  { id: 'c', sortMs: 300, title: 'new c' }, // brand new
];
const merged = N.mergeItems(prev, fresh, 300);
eq(merged.map((m) => m.id), ['c', 'b', 'a'], 'merge sorted desc');
eq(merged.find((m) => m.id === 'a').title, 'new a', 'merge fresh wins');
eq(N.mergeItems(prev, fresh, 2).length, 2, 'merge cap');

const seen = new Set(['a', 'b']);
eq(N.diffNew(merged, seen).map((m) => m.id), ['c'], 'diff new items only');

// ---------- firestore fetch (mocked) ----------
let fetchCalls = [];
function mockFetch(status, body) {
  global.fetch = async (url, init) => {
    fetchCalls.push({ url, init });
    return { ok: status >= 200 && status < 300, status, json: async () => body };
  };
}
const cfg = { kind: 'firestore', projectId: 'proj-1', apiKey: 'KEY', path: 'notifications', dbUrl: '', authEmail: '', authPassword: '' };

mockFetch(200, {
  documents: [
    { name: 'projects/proj-1/databases/(default)/documents/notifications/docA', updateTime: '2026-03-10T08:31:00Z', fields: { title: { stringValue: 'T1' }, body: { stringValue: 'B1' }, type: { stringValue: 'payment' }, createdAt: { timestampValue: '2026-03-10T08:30:00Z' } } },
    { name: 'projects/proj-1/databases/(default)/documents/notifications/docB', updateTime: '2026-03-10T08:31:00Z', fields: { heading: { stringValue: 'T2' }, message: { stringValue: 'B2' }, category: { stringValue: 'critical' } } },
  ],
});
(async () => {
  const items = await R.fetchFirestoreItems(cfg);
  eq(items.length, 2, 'firestore fetch count');
  eq(items[0].id, 'docA', 'firestore id');
  eq(items[0].title, 'T1', 'firestore title');
  eq(items[0].type, 'payment', 'firestore type');
  eq(items[0].timeMs, Date.parse('2026-03-10T08:30:00Z'), 'firestore time');
  eq(items[1].title, 'T2', 'firestore fallback title');
  eq(items[1].timeMs, Date.parse('2026-03-10T08:31:00Z'), 'firestore meta time fallback');
  ok(fetchCalls[0].url.includes('firestore.googleapis.com') && fetchCalls[0].url.includes('pageSize=250'), 'firestore url');
  ok(fetchCalls[0].init.headers['x-goog-api-key'] === 'KEY', 'firestore api key header');

  // error mapping
  mockFetch(403, { error: { message: 'PERMISSION_DENIED: missing or insufficient permissions' } });
  let threw = null;
  try { await R.fetchFirestoreItems(cfg); } catch (e) { threw = e; }
  ok(threw && /permission denied/i.test(threw.message), 'firestore 403 readable error: ' + (threw && threw.message));

  mockFetch(404, { error: { message: 'NOT_FOUND' } });
  threw = null;
  try { await R.fetchFirestoreItems(cfg); } catch (e) { threw = e; }
  ok(threw && /not found/i.test(threw.message), 'firestore 404 readable error');

  // ---------- rtdb fetch ----------
  const rcfg = { ...cfg, kind: 'rtdb', path: 'alerts', dbUrl: 'https://proj-1-default-rtdb.firebaseio.com' };
  mockFetch(200, {
    '-OxAbCdEf': { title: 'RT1', body: 'RB1', type: 'order', timestamp: 1770000000000 },
    '-OxAbCdEg': { heading: 'RT2', message: 'RB2', kind: 'info' },
  });
  const ritems = await R.fetchRtdbItems(rcfg);
  eq(ritems.length, 2, 'rtdb fetch count');
  eq(ritems[0].id, '-OxAbCdEf', 'rtdb key id');
  eq(ritems[0].title, 'RT1', 'rtdb title');
  eq(ritems[1].type, 'info', 'rtdb fallback type via kind');
  ok(fetchCalls[fetchCalls.length - 1].url === 'https://proj-1-default-rtdb.firebaseio.com/alerts.json', 'rtdb url: ' + fetchCalls[fetchCalls.length - 1].url);

  mockFetch(200, null);
  eq((await R.fetchRtdbItems(rcfg)).length, 0, 'rtdb empty node -> no items');

  // ---------- markDoneRemote (firestore) ----------
  fetchCalls = [];
  mockFetch(200, { name: 'x' });
  const item = { id: 'docA', statusField: 'status', kind: 'firestore' };
  await R.markDoneRemote(cfg, item, true);
  const call = fetchCalls[0];
  ok(call.init.method === 'PATCH', 'markDone uses PATCH');
  ok(/documents\/notifications\/docA\?/.test(call.url), 'markDone url targets doc');
  ok(call.url.includes('updateMask.fieldPaths=status'), 'markDone mask status');
  const bodySent = JSON.parse(call.init.body);
  eq(bodySent.fields.status.stringValue, 'done', 'markDone writes done');

  await R.markDoneRemote(cfg, { id: 'docA', statusField: 'done', kind: 'firestore' }, true);
  const body2 = JSON.parse(fetchCalls[1].init.body);
  eq(body2.fields.done.booleanValue, true, 'markDone bool field when statusField is done');

  // rtdb markDone
  await R.markDoneRemote(rcfg, { id: 'k1', statusField: null, kind: 'rtdb' }, true);
  const rc = fetchCalls[2];
  ok(rc.url === 'https://proj-1-default-rtdb.firebaseio.com/alerts/k1.json', 'rtdb markDone url');
  eq(JSON.parse(rc.init.body).status, 'done', 'rtdb markDone payload');

  // ---------- testConnection ----------
  mockFetch(200, { documents: [{ name: 'a' }] });
  const t = await R.testConnection(cfg);
  ok(t.ok && /1 document/.test(t.message), 'testConnection success message: ' + t.message);
  mockFetch(401, { error: { message: 'unauthorized' } });
  const t2 = await R.testConnection(cfg);
  ok(!t2.ok && /unauthorized|api key/i.test(t2.message), 'testConnection failure message: ' + t2.message);

  // ---------- auth ----------
  mockFetch(200, { idToken: 'tok123', expiresIn: '3600' });
  const acfg = { ...cfg, authEmail: 'u@x.com', authPassword: 'pw' };
  const tok = await R.getAuthToken(acfg);
  eq(tok, 'tok123', 'auth token fetched');
  ok(fetchCalls[fetchCalls.length - 1].url.includes('identitytoolkit.googleapis.com'), 'auth url');
  R.clearAuthCache();
  mockFetch(400, { error: { message: 'EMAIL_NOT_FOUND' } });
  let authErr = null;
  try { await R.getAuthToken(acfg, true); } catch (e) { authErr = e; }
  ok(authErr && /Sign-in failed: EMAIL_NOT_FOUND/.test(authErr.message), 'auth error readable: ' + (authErr && authErr.message));

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('TEST RUNNER ERROR', e); process.exit(2); });
