/**
 * DB Alert - watches a Firebase database and notifies about new entries.
 * WhatsApp-style UI: history list, deep-dive detail, mark as done.
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { AppState, StatusBar, StyleSheet, Text, View } from 'react-native';
import * as Notifications from 'expo-notifications';
import { AppConfig, Item } from './src/types';
import { markDoneRemote } from './src/lib/firebase-rest';
import { ensureNotificationPermission, updateBadge } from './src/lib/notify';
import { diagnose, ensureBackgroundPollRegistered, loadUiState, performCheck } from './src/lib/poll';
import {
  loadDoneIds,
  resetAllData,
  saveConfig,
  saveDoneIds,
  saveSeenIds,
  saveSeenInit,
  saveUnreadIds,
} from './src/lib/storage';
import ErrorBoundary from './src/ui/ErrorBoundary';
import ListScreen, { Tab } from './src/ui/ListScreen';
import DetailScreen from './src/ui/DetailScreen';
import SettingsScreen from './src/ui/SettingsScreen';
import { THEME } from './src/theme';

type ScreenView =
  | { name: 'list' }
  | { name: 'detail'; itemId: string }
  | { name: 'settings' };

const POLL_INTERVAL_MS = 15 * 60 * 1000; // 15 minutes

export default function App() {
  const [view, setView] = useState<ScreenView>({ name: 'list' });
  const [tab, setTab] = useState<Tab>('updates');
  const [items, setItems] = useState<Item[]>([]);
  const [unreadIds, setUnreadIds] = useState<Set<string>>(new Set());
  const [doneIds, setDoneIds] = useState<Set<string>>(new Set());
  const [config, setConfig] = useState<AppConfig | null>(null);
  const [checking, setChecking] = useState(false);
  const [saving, setSaving] = useState(false);
  const [dbWriteError, setDbWriteError] = useState<string | null>(null);
  const [diagnostics, setDiagnostics] = useState<Awaited<ReturnType<typeof diagnose>> | null>(null);

  const lastCheckRef = useRef(0);
  const pendingDetailRef = useRef<string | null>(null);
  const itemsRef = useRef<Item[]>([]);
  itemsRef.current = items;

  const refreshState = useCallback(async () => {
    try {
      const st = await loadUiState();
      setItems(st.items);
      setUnreadIds(st.unreadIds);
      setDoneIds(st.doneIds);
      setConfig(st.config);
      lastCheckRef.current = st.lastCheck;
      if (pendingDetailRef.current) {
        const id = pendingDetailRef.current;
        if (st.items.some((it) => it.id === id)) {
          pendingDetailRef.current = null;
          setView({ name: 'detail', itemId: id });
        }
      }
    } catch {
      // never crash on state load
    }
  }, []);

  const refreshDiagnostics = useCallback(async () => {
    try {
      setDiagnostics(await diagnose());
    } catch {
      // ignore
    }
  }, []);

  const checkNow = useCallback(async () => {
    setChecking(true);
    try {
      await performCheck();
      await refreshState();
      await refreshDiagnostics();
    } finally {
      setChecking(false);
    }
  }, [refreshState, refreshDiagnostics]);

  const openItem = useCallback((id: string) => {
    setDbWriteError(null);
    // mark as read
    setUnreadIds((prev) => {
      if (!prev.has(id)) return prev;
      const next = new Set(prev);
      next.delete(id);
      void saveUnreadIds(Array.from(next));
      void updateBadge(next.size);
      return next;
    });
    if (!itemsRef.current.some((it) => it.id === id)) {
      // items not loaded yet (cold start from a notification): resolve later
      pendingDetailRef.current = id;
      return;
    }
    setView((v) => {
      if (v.name === 'detail' && v.itemId === id) return v;
      return { name: 'detail', itemId: id };
    });
  }, []);

  // resolve a pending detail once items arrive (cold start from notification)
  useEffect(() => {
    if (pendingDetailRef.current && items.some((it) => it.id === pendingDetailRef.current)) {
      const id = pendingDetailRef.current;
      pendingDetailRef.current = null;
      setView({ name: 'detail', itemId: id });
    }
  }, [items]);

  // ---- mount: state, task registration, permission, listeners, poll loop ----
  useEffect(() => {
    let mounted = true;

    (async () => {
      await refreshState();
      await refreshDiagnostics();
      await ensureNotificationPermission();
      const registered = await ensureBackgroundPollRegistered();
      if (!registered) {
        // still poll in foreground; background checks unavailable (rare)
      }
      // first check shortly after launch
      if (lastCheckRef.current === 0 || Date.now() - lastCheckRef.current > POLL_INTERVAL_MS - 60000) {
        if (mounted) void checkNow();
      }
    })();

    // notification tapped
    const sub = Notifications.addNotificationResponseReceivedListener((response) => {
      try {
        const data = response.notification.request.content.data as { itemId?: string } | undefined;
        if (data && typeof data.itemId === 'string') openItem(data.itemId);
      } catch {
        // ignore malformed payloads
      }
    });

    // cold start from a notification
    (async () => {
      try {
        const last = await Notifications.getLastNotificationResponseAsync();
        if (
          last &&
          last.actionIdentifier === Notifications.DEFAULT_ACTION_IDENTIFIER &&
          Date.now() - (last.notification.date || 0) < 120000
        ) {
          const data = last.notification.request.content.data as { itemId?: string } | undefined;
          if (data && typeof data.itemId === 'string') openItem(data.itemId);
        }
      } catch {
        // ignore
      }
    })();

    // app came back to foreground -> resync with any background work
    const appStateSub = AppState.addEventListener('change', (s) => {
      if (s === 'active') {
        void refreshState();
        void refreshDiagnostics();
      }
    });

    // foreground poll ticker
    const timer = setInterval(() => {
      if (Date.now() - lastCheckRef.current >= POLL_INTERVAL_MS) {
        void checkNow();
      }
    }, 60000);

    return () => {
      mounted = false;
      sub.remove();
      appStateSub.remove();
      clearInterval(timer);
    };
  }, [checkNow, openItem, refreshState, refreshDiagnostics]);

  // ---- actions ----
  const handleToggleDone = useCallback(
    async (item: Item, next: boolean) => {
      setSaving(true);
      setDbWriteError(null);
      // 1. local mark (always works, offline-friendly)
      const current = await loadDoneIds();
      const set = new Set(current);
      if (next) set.add(item.id);
      else set.delete(item.id);
      await saveDoneIds(Array.from(set));
      setDoneIds(set);
      // 2. try writing back to the database
      try {
        const cfg = config;
        if (cfg) {
          await markDoneRemote(cfg, item, next);
        }
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        setDbWriteError(msg);
      } finally {
        setSaving(false);
      }
    },
    [config]
  );

  const handleSaveConfig = useCallback(
    async (cfg: AppConfig) => {
      const prev = config;
      await saveConfig(cfg);
      setConfig(cfg);
      // connecting to a different database: re-baseline so we do not spam
      const dbChanged =
        prev !== null &&
        (prev.kind !== cfg.kind ||
          prev.projectId !== cfg.projectId ||
          prev.path !== cfg.path ||
          prev.dbUrl !== cfg.dbUrl);
      if (dbChanged) {
        await saveSeenIds([]);
        await saveSeenInit();
        await saveUnreadIds([]);
      }
      await ensureBackgroundPollRegistered();
      await checkNow();
      await refreshDiagnostics();
      setView({ name: 'list' });
    },
    [config, checkNow, refreshDiagnostics]
  );

  const handleReset = useCallback(async () => {
    await resetAllData();
    await refreshState();
    await refreshDiagnostics();
    setView({ name: 'list' });
  }, [refreshState, refreshDiagnostics]);

  // ---- render ----
  const configured = Boolean(
    config &&
      (config.kind === 'firestore'
        ? config.projectId.trim() && config.path.trim()
        : (config.dbUrl.trim() || config.projectId.trim()) && config.path.trim())
  );

  let screen: React.ReactNode = null;
  if (view.name === 'list') {
    screen = (
      <ListScreen
        items={items}
        tab={tab}
        onTabChange={setTab}
        unreadIds={unreadIds}
        doneIds={doneIds}
        configured={configured}
        checking={checking}
        onRefresh={checkNow}
        onOpenItem={openItem}
        onOpenSettings={() => {
          setDbWriteError(null);
          setView({ name: 'settings' });
          void refreshDiagnostics();
        }}
      />
    );
  } else if (view.name === 'detail') {
    const item = items.find((it) => it.id === view.itemId);
    if (item) {
      const isDone = doneIds.has(item.id) || item.remoteDone;
      screen = (
        <DetailScreen
          item={item}
          isDone={isDone}
          saving={saving}
          dbWriteError={dbWriteError}
          onBack={() => setView({ name: 'list' })}
          onToggleDone={handleToggleDone}
        />
      );
    } else {
      screen = <MissingItem onBack={() => setView({ name: 'list' })} />;
    }
  } else {
    screen = (
      <SettingsScreen
        initial={config ?? { kind: 'firestore', projectId: '', apiKey: '', path: 'notifications', dbUrl: '', authEmail: '', authPassword: '' }}
        diagnostics={diagnostics}
        onSave={handleSaveConfig}
        onReset={handleReset}
        onReloadDiagnostics={() => {
          void refreshDiagnostics();
          setView({ name: 'list' });
        }}
      />
    );
  }

  return (
    <ErrorBoundary>
      <View style={styles.root}>
        <StatusBar barStyle="light-content" backgroundColor={THEME.headerDark} translucent />
        {screen}
      </View>
    </ErrorBoundary>
  );
}

function MissingItem({ onBack }: { onBack: () => void }) {
  return (
    <View style={styles.missing}>
      <Text style={styles.missingText}>This update is no longer in the history.</Text>
      <Text style={styles.missingBtn} onPress={onBack}>
        Back to updates
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: THEME.header },
  missing: { flex: 1, backgroundColor: THEME.listBg, alignItems: 'center', justifyContent: 'center', padding: 30 },
  missingText: { color: THEME.textSecondary, fontSize: 15, textAlign: 'center', marginBottom: 16 },
  missingBtn: { color: THEME.header, fontSize: 15, fontWeight: '700' },
});
